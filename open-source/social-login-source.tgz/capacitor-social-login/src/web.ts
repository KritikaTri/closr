import { WebPlugin } from '@capacitor/core';

import { AppleSocialLogin } from './apple-provider';
import type {
  SocialLoginPlugin,
  InitializeOptions,
  LoginOptions,
  AuthorizationCode,
  AuthorizationCodeOptions,
  isLoggedInOptions,
  ProviderResponseMap,
  FacebookLoginOptions,
  ProviderSpecificCall,
  ProviderSpecificCallOptionsMap,
  ProviderSpecificCallResponseMap,
  LoginResult,
  OAuth2LoginOptions,
  OAuth2LoginResponse,
  OAuth2ProviderConfig,
  OpenAuthSessionOptions,
  OpenAuthSessionResult,
  OpenSecureWindowOptions,
  OpenSecureWindowResponse,
  FacebookGetProfileOptions,
  TelegramLoginOptions,
  LinkedInLoginOptions,
  TikTokLoginOptions,
  RefreshTokenOptions,
} from './definitions';
import { createUserCancelledError, inferUserCancelledError } from './errors';
import { FacebookSocialLogin } from './facebook-provider';
import { GoogleSocialLogin } from './google-provider';
import {
  asLinkedInLoginResult,
  buildLinkedInLoginOptions,
  buildLinkedInOAuthConfig,
  consumeLinkedInRedirectPending,
  isLinkedInOAuthResult,
  LINKEDIN_PROVIDER_ID,
  markLinkedInRedirectPending,
} from './linkedin-provider';
import {
  clearOAuthPopupMarker,
  deliverOAuthResult,
  OAUTH_STATE_KEY,
  shouldAutoFinishOAuthRedirect,
  type OAuthBridgeMessage,
} from './oauth-popup-bridge';
import { OAuth2SocialLogin } from './oauth2-provider';
import { TelegramSocialLogin } from './telegram-provider';
import {
  asTikTokLoginResult,
  buildTikTokLoginOptions,
  buildTikTokOAuthConfig,
  isTikTokOAuthResult,
  TIKTOK_PROVIDER_ID,
} from './tiktok-provider';
import { TwitterSocialLogin } from './twitter-provider';
import { nextPopupClosePollState, type PopupClosePollState } from './web-auth-popup-close';

export class SocialLoginWeb extends WebPlugin implements SocialLoginPlugin {
  private static readonly OAUTH_STATE_KEY = OAUTH_STATE_KEY;

  private googleProvider: GoogleSocialLogin;
  private appleProvider: AppleSocialLogin;
  private facebookProvider: FacebookSocialLogin;
  private twitterProvider: TwitterSocialLogin;
  private telegramProvider: TelegramSocialLogin;
  private oauth2Provider: OAuth2SocialLogin;
  private webAuthPopupInProgress = false;

  constructor() {
    super();

    this.googleProvider = new GoogleSocialLogin();
    this.appleProvider = new AppleSocialLogin();
    this.facebookProvider = new FacebookSocialLogin();
    this.twitterProvider = new TwitterSocialLogin();
    this.telegramProvider = new TelegramSocialLogin();
    this.oauth2Provider = new OAuth2SocialLogin();

    // Auto-finish OAuth redirects only when running inside a popup window.
    // For redirect-based flows (full page navigation), the app should call `handleRedirectCallback()` explicitly.
    // Note: oauth-popup-redirect.ts also handles this eagerly on package import for COOP-safe popup completion.
    if (shouldAutoFinishOAuthRedirect()) {
      this.finishOAuthRedirectInPopup().catch((error) => {
        console.error('Failed to finish OAuth redirect', error);
        try {
          window.close();
        } catch {
          // ignore
        }
      });
    }
  }

  private async parseRedirectResult(): Promise<{
    provider: string | null;
    state?: string;
    nonce?: string;
    result: LoginResult | { error: string } | null;
  }> {
    const url = new URL(window.location.href);
    const stateRaw = localStorage.getItem(SocialLoginWeb.OAUTH_STATE_KEY);
    let provider: string | null = null;
    let state: string | undefined;
    let nonce: string | undefined;

    if (stateRaw) {
      try {
        const parsed = JSON.parse(stateRaw);
        provider = parsed.provider ?? null;
        state = parsed.state;
        nonce = parsed.nonce;
      } catch {
        provider = stateRaw === 'true' ? 'google' : null;
      }
    }

    let result: LoginResult | { error: string } | null;

    switch (provider) {
      case 'twitter':
        result = await this.twitterProvider.handleOAuthRedirect(url, state);
        break;
      case 'telegram':
        result = await this.telegramProvider.handleOAuthRedirect(url, state);
        break;
      case 'oauth2':
        result = await this.oauth2Provider.handleOAuthRedirect(url, state);
        break;
      case 'google':
      default:
        result = this.googleProvider.handleOAuthRedirect(url);
        break;
    }

    return { provider, state, nonce, result };
  }

  private async finishOAuthRedirectInPopup(): Promise<void> {
    const parsed = await this.parseRedirectResult();
    const nonceOrState = parsed.nonce ?? parsed.state;
    let message: OAuthBridgeMessage;

    if (!parsed.result) {
      message = {
        type: 'oauth-error',
        provider: parsed.provider,
        error: 'OAuth redirect did not contain expected parameters.',
      };
    } else if ('error' in parsed.result) {
      const resolvedProvider = parsed.provider ?? null;
      const error = inferUserCancelledError(parsed.result.error);
      message = {
        type: 'oauth-error',
        provider: resolvedProvider,
        error: error.message,
        ...(error.code ? { code: error.code } : null),
      };
    } else {
      message = {
        type: 'oauth-response',
        provider: parsed.result.provider,
        ...parsed.result.result,
      };
    }

    deliverOAuthResult(parsed.provider ?? 'google', nonceOrState, message);
    clearOAuthPopupMarker();

    try {
      window.close();
    } catch {
      // Popup may not be allowed to close itself in some contexts
    }
  }

  async initialize(options: InitializeOptions): Promise<void> {
    const initPromises: Promise<void>[] = [];

    if (options.google?.webClientId) {
      initPromises.push(
        this.googleProvider.initialize(
          options.google.webClientId,
          options.google.mode,
          options.google.hostedDomain,
          options.google.redirectUrl,
        ),
      );
    }

    if (options.apple?.clientId) {
      initPromises.push(
        this.appleProvider.initialize(
          options.apple.clientId,
          options.apple.redirectUrl,
          options.apple.useProperTokenExchange,
        ),
      );
    }

    if (options.facebook?.appId) {
      initPromises.push(this.facebookProvider.initialize(options.facebook.appId, options.facebook.locale));
    }

    if (options.twitter?.clientId) {
      initPromises.push(
        this.twitterProvider.initialize(
          options.twitter.clientId,
          options.twitter.redirectUrl,
          options.twitter.defaultScopes,
          options.twitter.forceLogin,
          options.twitter.audience,
        ),
      );
    }

    if (options.telegram?.botId) {
      this.telegramProvider.initialize(
        options.telegram.botId,
        options.telegram.requestAccess,
        options.telegram.redirectUrl,
        options.telegram.origin,
        options.telegram.languageCode,
      );
    }

    const oauth2Configs: Record<string, OAuth2ProviderConfig> = { ...(options.oauth2 ?? {}) };
    if (options.linkedin && !oauth2Configs[LINKEDIN_PROVIDER_ID]) {
      oauth2Configs[LINKEDIN_PROVIDER_ID] = buildLinkedInOAuthConfig(options.linkedin);
    }
    if (options.tiktok) {
      if (!options.tiktok.clientKey || !options.tiktok.redirectUrl) {
        throw new Error('tiktok.clientKey and tiktok.redirectUrl are required');
      }
      if (!oauth2Configs[TIKTOK_PROVIDER_ID]) {
        oauth2Configs[TIKTOK_PROVIDER_ID] = buildTikTokOAuthConfig(options.tiktok);
      }
    }
    if (Object.keys(oauth2Configs).length > 0) {
      initPromises.push(this.oauth2Provider.initializeProviders(oauth2Configs));
    }

    await Promise.all(initPromises);
  }

  async login<T extends LoginOptions['provider']>(
    options: Extract<LoginOptions, { provider: T }>,
  ): Promise<{ provider: T; result: ProviderResponseMap[T] }> {
    switch (options.provider) {
      case 'google':
        return this.googleProvider.login(options.options as any) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      case 'apple':
        return this.appleProvider.login(options.options as any) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      case 'facebook':
        return this.facebookProvider.login(options.options as FacebookLoginOptions) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      case 'twitter':
        return this.twitterProvider.login(options.options as any) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      case 'telegram':
        return this.telegramProvider.login(options.options as TelegramLoginOptions) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      case 'linkedin': {
        const linkedInOptions = (options.options as LinkedInLoginOptions | undefined) ?? {};
        const oauthOptions = buildLinkedInLoginOptions(linkedInOptions);
        if (oauthOptions.flow === 'redirect' && oauthOptions.state) {
          markLinkedInRedirectPending(oauthOptions.state);
        }
        const response = await this.oauth2Provider.login(oauthOptions);
        return asLinkedInLoginResult(response) as { provider: T; result: ProviderResponseMap[T] };
      }
      case 'tiktok': {
        const response = await this.oauth2Provider.login(
          buildTikTokLoginOptions(options.options as TikTokLoginOptions),
        );
        return asTikTokLoginResult(response) as { provider: T; result: ProviderResponseMap[T] };
      }
      case 'oauth2':
        return this.oauth2Provider.login(options.options as OAuth2LoginOptions) as Promise<{
          provider: T;
          result: ProviderResponseMap[T];
        }>;
      default:
        throw new Error(`Login for ${options.provider} is not implemented on web`);
    }
  }

  async logout(options: {
    provider: 'apple' | 'google' | 'facebook' | 'twitter' | 'telegram' | 'linkedin' | 'tiktok' | 'oauth2';
    providerId?: string;
    clearCachedUserInfo?: boolean;
  }): Promise<void> {
    switch (options.provider) {
      case 'google':
        return this.googleProvider.logout();
      case 'apple':
        return this.appleProvider.logout();
      case 'facebook':
        return this.facebookProvider.logout();
      case 'twitter':
        return this.twitterProvider.logout();
      case 'telegram':
        return this.telegramProvider.logout();
      case 'linkedin':
        return this.oauth2Provider.logout(LINKEDIN_PROVIDER_ID);
      case 'tiktok':
        return this.oauth2Provider.logout(TIKTOK_PROVIDER_ID);
      case 'oauth2':
        if (!options.providerId) {
          throw new Error('providerId is required for oauth2 logout');
        }
        return this.oauth2Provider.logout(options.providerId);
      default:
        throw new Error(`Logout for ${options.provider} is not implemented`);
    }
  }

  async isLoggedIn(options: isLoggedInOptions): Promise<{ isLoggedIn: boolean }> {
    switch (options.provider) {
      case 'google':
        return this.googleProvider.isLoggedIn();
      case 'apple':
        return this.appleProvider.isLoggedIn();
      case 'facebook':
        return this.facebookProvider.isLoggedIn();
      case 'twitter':
        return this.twitterProvider.isLoggedIn();
      case 'telegram':
        return this.telegramProvider.isLoggedIn();
      case 'linkedin':
        return this.oauth2Provider.isLoggedIn(LINKEDIN_PROVIDER_ID);
      case 'tiktok':
        return this.oauth2Provider.isLoggedIn(TIKTOK_PROVIDER_ID);
      case 'oauth2':
        if (!options.providerId) {
          throw new Error('providerId is required for oauth2 isLoggedIn');
        }
        return this.oauth2Provider.isLoggedIn(options.providerId);
      default:
        throw new Error(`isLoggedIn for ${options.provider} is not implemented`);
    }
  }

  async getAuthorizationCode(options: AuthorizationCodeOptions): Promise<AuthorizationCode> {
    switch (options.provider) {
      case 'google':
        return this.googleProvider.getAuthorizationCode();
      case 'apple':
        return this.appleProvider.getAuthorizationCode();
      case 'facebook':
        return this.facebookProvider.getAuthorizationCode();
      case 'twitter':
        return this.twitterProvider.getAuthorizationCode();
      case 'linkedin':
        return this.oauth2Provider.getAuthorizationCode(LINKEDIN_PROVIDER_ID);
      case 'tiktok':
        return this.oauth2Provider.getAuthorizationCode(TIKTOK_PROVIDER_ID);
      case 'oauth2':
        if (!options.providerId) {
          throw new Error('providerId is required for oauth2 getAuthorizationCode');
        }
        return this.oauth2Provider.getAuthorizationCode(options.providerId);
      default:
        throw new Error(`getAuthorizationCode for ${options.provider} is not implemented`);
    }
  }

  async refresh(options: LoginOptions): Promise<void> {
    switch (options.provider) {
      case 'google':
        return this.googleProvider.refresh();
      case 'apple':
        return this.appleProvider.refresh();
      case 'facebook':
        return this.facebookProvider.refresh(options.options as FacebookLoginOptions);
      case 'twitter':
        return this.twitterProvider.refresh();
      case 'telegram':
        return this.telegramProvider.refresh();
      case 'linkedin':
        return this.oauth2Provider.refresh(LINKEDIN_PROVIDER_ID);
      case 'tiktok':
        return this.oauth2Provider.refresh(TIKTOK_PROVIDER_ID);
      case 'oauth2': {
        const oauth2Options = options.options as OAuth2LoginOptions;
        if (!oauth2Options?.providerId) {
          throw new Error('providerId is required for oauth2 refresh');
        }
        return this.oauth2Provider.refresh(oauth2Options.providerId);
      }
      default:
        throw new Error(`Refresh for ${(options as any).provider} is not implemented`);
    }
  }

  async providerSpecificCall<T extends ProviderSpecificCall>(options: {
    call: T;
    options: ProviderSpecificCallOptionsMap[T];
  }): Promise<ProviderSpecificCallResponseMap[T]> {
    switch (options.call) {
      case 'facebook#getProfile': {
        const fields = (options.options as FacebookGetProfileOptions | undefined)?.fields;
        return this.facebookProvider.getProfile(fields) as Promise<ProviderSpecificCallResponseMap[T]>;
      }
      case 'facebook#requestTracking':
        return this.facebookProvider.requestTracking() as Promise<ProviderSpecificCallResponseMap[T]>;
      case 'google#createRestoreCredential':
      case 'google#getRestoreCredential':
      case 'google#clearRestoreCredential':
        throw new Error(`${options.call} is only available on Android`);
      default:
        throw new Error(`Provider specific call for ${options.call} is not implemented`);
    }
  }

  async refreshToken(options: RefreshTokenOptions): Promise<OAuth2LoginResponse> {
    if (options.provider === 'linkedin') {
      return this.oauth2Provider.refreshToken(LINKEDIN_PROVIDER_ID, options.refreshToken, options.additionalParameters);
    }
    if (options.provider === 'tiktok') {
      return this.oauth2Provider.refreshToken(TIKTOK_PROVIDER_ID, options.refreshToken, options.additionalParameters);
    }
    if (options.provider !== 'oauth2') {
      throw new Error('refreshToken is only implemented for oauth2, linkedin, and tiktok on web');
    }
    return this.oauth2Provider.refreshToken(options.providerId, options.refreshToken, options.additionalParameters);
  }

  async handleRedirectCallback(): Promise<LoginResult | null> {
    const parsed = await this.parseRedirectResult();
    const callbackState = parsed.state ?? new URL(window.location.href).searchParams.get('state');
    const pendingLinkedInRedirect = consumeLinkedInRedirectPending(callbackState);
    const result = parsed.result;
    if (!result) return null;
    if ('error' in result) {
      throw inferUserCancelledError(result.error);
    }
    if (pendingLinkedInRedirect && isLinkedInOAuthResult(result)) {
      return asLinkedInLoginResult(result);
    }
    if (isTikTokOAuthResult(result)) {
      return asTikTokLoginResult(result);
    }
    return result;
  }

  async decodeIdToken(options: { idToken?: string; token?: string }): Promise<{ claims: Record<string, any> }> {
    const token = options?.idToken ?? options?.token;
    if (!token) {
      throw new Error('idToken (or token) is required');
    }
    const claims = this.oauth2Provider.decodeIdToken(token);
    return { claims };
  }

  async getAccessTokenExpirationDate(options: { accessTokenExpirationDate: number }): Promise<{ date: string }> {
    if (typeof options?.accessTokenExpirationDate !== 'number') {
      throw new Error('accessTokenExpirationDate is required');
    }
    return { date: new Date(options.accessTokenExpirationDate).toISOString() };
  }

  async isAccessTokenAvailable(options: { accessToken: string | null }): Promise<{ isAvailable: boolean }> {
    const token = options?.accessToken ?? null;
    return { isAvailable: typeof token === 'string' && token.length > 0 };
  }

  async isAccessTokenExpired(options: { accessTokenExpirationDate: number }): Promise<{ isExpired: boolean }> {
    if (typeof options?.accessTokenExpirationDate !== 'number') {
      throw new Error('accessTokenExpirationDate is required');
    }
    return { isExpired: options.accessTokenExpirationDate <= Date.now() };
  }

  async isRefreshTokenAvailable(options: { refreshToken: string | null }): Promise<{ isAvailable: boolean }> {
    const token = options?.refreshToken ?? null;
    return { isAvailable: typeof token === 'string' && token.length > 0 };
  }

  async getPluginVersion(): Promise<{ version: string }> {
    return { version: 'web' };
  }

  async openSecureWindow(options: OpenSecureWindowOptions): Promise<OpenSecureWindowResponse> {
    const callbackURL = await this.runWebAuthPopup({
      url: options.authEndpoint,
      redirectPrefix: options.redirectUri,
      broadcastChannelName: options.broadcastChannelName,
    });
    return { redirectedUri: callbackURL };
  }

  async openAuthSession(options: OpenAuthSessionOptions): Promise<OpenAuthSessionResult> {
    const redirectPrefixes = [`${options.callbackURLScheme}://`];
    try {
      const authUrl = new URL(options.url);
      const redirectUri = authUrl.searchParams.get('redirect_uri');
      if (redirectUri && /^https?:\/\//i.test(redirectUri) && !redirectPrefixes.includes(redirectUri)) {
        redirectPrefixes.unshift(redirectUri);
      }
    } catch {
      // ignore malformed authorize URLs; scheme prefix remains the fallback
    }

    const callbackURL = await this.runWebAuthPopup({
      url: options.url,
      redirectPrefixes,
      broadcastChannelName: options.broadcastChannelName ?? 'capgo-auth-session',
    });
    return { callbackURL };
  }

  private runWebAuthPopup(options: {
    url: string;
    redirectPrefix?: string;
    redirectPrefixes?: string[];
    broadcastChannelName?: string;
  }): Promise<string> {
    if (this.webAuthPopupInProgress) {
      return Promise.reject(new Error('Another auth session is already in progress'));
    }
    this.webAuthPopupInProgress = true;

    let popup: Window | null = null;
    let bc: BroadcastChannel | null = null;
    let pollTimer = 0;
    let timeoutTimer = 0;

    const releasePopupGuard = () => {
      this.webAuthPopupInProgress = false;
      if (pollTimer) {
        window.clearInterval(pollTimer);
        pollTimer = 0;
      }
      if (timeoutTimer) {
        window.clearTimeout(timeoutTimer);
        timeoutTimer = 0;
      }
      if (bc) {
        try {
          bc.close();
        } catch {
          // ignore close errors
        }
        bc = null;
      }
    };

    try {
      const w = 600;
      const h = 550;
      const settings = [
        ['width', w],
        ['height', h],
        ['left', screen.width / 2 - w / 2],
        ['top', screen.height / 2 - h / 2],
      ]
        .map((x) => x.join('='))
        .join(',');

      popup = window.open(options.url, 'Authorization', settings);
      if (!popup) {
        releasePopupGuard();
        return Promise.reject(new Error('Unable to open authorization popup. Allow popups for this origin.'));
      }
      if (typeof popup.focus === 'function') {
        popup.focus();
      }

      const channelName = options.broadcastChannelName ?? 'oauth-channel';
      bc = new BroadcastChannel(channelName);
    } catch (error) {
      releasePopupGuard();
      if (popup && !popup.closed) {
        try {
          popup.close();
        } catch {
          // ignore cross-origin close errors
        }
      }
      throw error;
    }

    const activePopup = popup;
    const activeBc = bc;
    if (!activeBc) {
      releasePopupGuard();
      return Promise.reject(new Error('Unable to open authorization channel'));
    }

    return new Promise((resolve, reject) => {
      let settled = false;
      const prefixes = options.redirectPrefixes ?? (options.redirectPrefix != null ? [options.redirectPrefix] : []);

      const finish = (handler: () => void) => {
        if (settled) {
          return;
        }
        settled = true;
        releasePopupGuard();
        handler();
      };

      activeBc.addEventListener('message', (event) => {
        const data = typeof event.data === 'string' ? event.data : String(event.data ?? '');
        if (prefixes.some((prefix) => data.startsWith(prefix))) {
          finish(() => resolve(data));
          return;
        }
        const looksLikeRedirect = /^https?:\/\//i.test(data) || /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(data);
        if (looksLikeRedirect) {
          finish(() =>
            reject(
              new Error(
                'Redirect URI does not match expected prefix. Received: ' +
                  data +
                  ' Expected one of: ' +
                  prefixes.join(', '),
              ),
            ),
          );
        }
      });

      let popupClosePollState: PopupClosePollState = { graceStartedAtMs: null };

      pollTimer = window.setInterval(() => {
        try {
          const closed = activePopup.closed;
          const pollResult = nextPopupClosePollState(closed, popupClosePollState, Date.now());
          popupClosePollState = pollResult.state;
          if (pollResult.shouldCancel) {
            finish(() => reject(createUserCancelledError('User cancelled authorization')));
          }
        } catch {
          window.clearInterval(pollTimer);
          pollTimer = 0;
        }
      }, 500);

      timeoutTimer = window.setTimeout(() => {
        finish(() => reject(new Error('The sign-in flow timed out')));
      }, 5 * 60000);
    });
  }
}
