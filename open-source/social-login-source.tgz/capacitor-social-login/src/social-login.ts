import { registerPlugin } from '@capacitor/core';

// Eagerly finish OAuth popup redirects before plugin lazy-load (COOP-safe)
import './oauth-popup-redirect';

import type {
  AuthorizationCode,
  AuthorizationCodeOptions,
  InitializeOptions,
  LinkedInLoginOptions,
  LoginOptions,
  OpenAuthSessionOptions,
  OpenAuthSessionResult,
  OpenSecureWindowOptions,
  OpenSecureWindowResponse,
  OAuth2LoginResponse,
  ProviderResponseMap,
  RefreshTokenOptions,
  ProviderSpecificCall,
  ProviderSpecificCallOptionsMap,
  ProviderSpecificCallResponseMap,
  SocialLoginPlugin,
  TikTokLoginOptions,
  isLoggedInOptions,
} from './definitions';
import {
  asLinkedInLoginResult,
  buildLinkedInLoginOptions,
  buildLinkedInOAuthConfig,
  LINKEDIN_PROVIDER_ID,
  markLinkedInRedirectPending,
} from './linkedin-provider';
import {
  asTikTokLoginResult,
  buildTikTokLoginOptions,
  buildTikTokOAuthConfig,
  isTikTokOAuthResult,
  TIKTOK_PROVIDER_ID,
} from './tiktok-provider';

const GOOGLE_OFFLINE_REFRESH_MESSAGE =
  "Google refresh() is not available when using offline mode. Offline mode only returns serverAuthCode for backend token exchange. Send serverAuthCode to your backend and refresh tokens there, or switch google.mode to 'online' for client-side refresh.";

const rawSocialLogin = registerPlugin<SocialLoginPlugin>('SocialLogin', {
  web: () => import('./web').then((m) => new m.SocialLoginWeb()),
});

class SocialLoginClient implements SocialLoginPlugin {
  private initializeOptions?: InitializeOptions;

  private normalizeInitializeOptions(options: InitializeOptions): InitializeOptions {
    let next = options;

    if (next.linkedin) {
      const { linkedin, oauth2, ...rest } = next;
      next = {
        ...rest,
        linkedin,
        oauth2: {
          ...(oauth2 ?? {}),
          [LINKEDIN_PROVIDER_ID]: oauth2?.[LINKEDIN_PROVIDER_ID] ?? buildLinkedInOAuthConfig(linkedin),
        },
      };
    }

    if (next.tiktok) {
      if (!next.tiktok.clientKey || !next.tiktok.redirectUrl) {
        throw new Error('tiktok.clientKey and tiktok.redirectUrl are required');
      }
      const { tiktok, oauth2, ...rest } = next;
      next = {
        ...rest,
        tiktok,
        oauth2: {
          ...(oauth2 ?? {}),
          [TIKTOK_PROVIDER_ID]: oauth2?.[TIKTOK_PROVIDER_ID] ?? buildTikTokOAuthConfig(tiktok),
        },
      };
    }

    return next;
  }

  constructor() {
    this.initialize = this.initialize.bind(this);
    this.refresh = this.refresh.bind(this);
  }

  async initialize(options: InitializeOptions): Promise<void> {
    const normalized = this.normalizeInitializeOptions(options);
    await rawSocialLogin.initialize(normalized);
    this.initializeOptions = normalized;
  }

  async login<T extends LoginOptions['provider']>(
    options: Extract<LoginOptions, { provider: T }>,
  ): Promise<{ provider: T; result: ProviderResponseMap[T] }> {
    if (options.provider === 'linkedin') {
      const linkedInOptions = (options.options as LinkedInLoginOptions | undefined) ?? {};
      const oauthOptions = buildLinkedInLoginOptions(linkedInOptions);
      if (oauthOptions.flow === 'redirect' && oauthOptions.state) {
        markLinkedInRedirectPending(oauthOptions.state);
      }
      const response = await rawSocialLogin.login({
        provider: 'oauth2',
        options: oauthOptions,
      });
      return asLinkedInLoginResult(response) as { provider: T; result: ProviderResponseMap[T] };
    }
    if (options.provider === 'tiktok') {
      const response = await rawSocialLogin.login({
        provider: 'oauth2',
        options: buildTikTokLoginOptions(options.options as TikTokLoginOptions),
      });
      return asTikTokLoginResult(response) as { provider: T; result: ProviderResponseMap[T] };
    }
    return rawSocialLogin.login(options);
  }

  async logout(options: {
    provider: 'apple' | 'google' | 'facebook' | 'twitter' | 'telegram' | 'linkedin' | 'tiktok' | 'oauth2';
    providerId?: string;
    clearCachedUserInfo?: boolean;
  }): Promise<void> {
    if (options.provider === 'linkedin') {
      return rawSocialLogin.logout({ provider: 'oauth2', providerId: LINKEDIN_PROVIDER_ID });
    }
    if (options.provider === 'tiktok') {
      return rawSocialLogin.logout({ provider: 'oauth2', providerId: TIKTOK_PROVIDER_ID });
    }
    return rawSocialLogin.logout(options);
  }

  async isLoggedIn(options: isLoggedInOptions): Promise<{ isLoggedIn: boolean }> {
    if (options.provider === 'linkedin') {
      return rawSocialLogin.isLoggedIn({ provider: 'oauth2', providerId: LINKEDIN_PROVIDER_ID });
    }
    if (options.provider === 'tiktok') {
      return rawSocialLogin.isLoggedIn({ provider: 'oauth2', providerId: TIKTOK_PROVIDER_ID });
    }
    return rawSocialLogin.isLoggedIn(options);
  }

  async getAuthorizationCode(options: AuthorizationCodeOptions): Promise<AuthorizationCode> {
    if (options.provider === 'linkedin') {
      return rawSocialLogin.getAuthorizationCode({ provider: 'oauth2', providerId: LINKEDIN_PROVIDER_ID });
    }
    if (options.provider === 'tiktok') {
      return rawSocialLogin.getAuthorizationCode({ provider: 'oauth2', providerId: TIKTOK_PROVIDER_ID });
    }
    return rawSocialLogin.getAuthorizationCode(options);
  }

  async refresh(options: LoginOptions): Promise<void> {
    if (options.provider === 'google' && this.initializeOptions?.google?.mode === 'offline') {
      console.warn(`[SocialLogin] ${GOOGLE_OFFLINE_REFRESH_MESSAGE}`);
    }
    if (options.provider === 'linkedin') {
      return rawSocialLogin.refresh({
        provider: 'oauth2',
        options: buildLinkedInLoginOptions((options.options as LinkedInLoginOptions | undefined) ?? {}),
      });
    }
    if (options.provider === 'tiktok') {
      return rawSocialLogin.refresh({
        provider: 'oauth2',
        options: buildTikTokLoginOptions(options.options as TikTokLoginOptions),
      });
    }
    return rawSocialLogin.refresh(options);
  }

  async refreshToken(options: RefreshTokenOptions): Promise<OAuth2LoginResponse> {
    if (options.provider === 'linkedin') {
      return rawSocialLogin.refreshToken({
        provider: 'oauth2',
        providerId: LINKEDIN_PROVIDER_ID,
        refreshToken: options.refreshToken,
        additionalParameters: options.additionalParameters,
      });
    }
    if (options.provider === 'tiktok') {
      return rawSocialLogin.refreshToken({
        provider: 'oauth2',
        providerId: TIKTOK_PROVIDER_ID,
        refreshToken: options.refreshToken,
        additionalParameters: options.additionalParameters,
      });
    }
    return rawSocialLogin.refreshToken(options);
  }

  async handleRedirectCallback() {
    const result = await rawSocialLogin.handleRedirectCallback();
    if (result && isTikTokOAuthResult(result)) {
      return asTikTokLoginResult(result);
    }
    return result;
  }

  async decodeIdToken(options: { idToken?: string; token?: string }): Promise<{ claims: Record<string, any> }> {
    return rawSocialLogin.decodeIdToken(options);
  }

  async getAccessTokenExpirationDate(options: { accessTokenExpirationDate: number }): Promise<{ date: string }> {
    return rawSocialLogin.getAccessTokenExpirationDate(options);
  }

  async isAccessTokenAvailable(options: { accessToken: string | null }): Promise<{ isAvailable: boolean }> {
    return rawSocialLogin.isAccessTokenAvailable(options);
  }

  async isAccessTokenExpired(options: { accessTokenExpirationDate: number }): Promise<{ isExpired: boolean }> {
    return rawSocialLogin.isAccessTokenExpired(options);
  }

  async isRefreshTokenAvailable(options: { refreshToken: string | null }): Promise<{ isAvailable: boolean }> {
    return rawSocialLogin.isRefreshTokenAvailable(options);
  }

  async providerSpecificCall<T extends ProviderSpecificCall>(options: {
    call: T;
    options: ProviderSpecificCallOptionsMap[T];
  }): Promise<ProviderSpecificCallResponseMap[T]> {
    return rawSocialLogin.providerSpecificCall(options);
  }

  async getPluginVersion(): Promise<{ version: string }> {
    return rawSocialLogin.getPluginVersion();
  }

  async openSecureWindow(options: OpenSecureWindowOptions): Promise<OpenSecureWindowResponse> {
    return rawSocialLogin.openSecureWindow(options);
  }

  async openAuthSession(options: OpenAuthSessionOptions): Promise<OpenAuthSessionResult> {
    return rawSocialLogin.openAuthSession(options);
  }
}

export const SocialLoginBase = rawSocialLogin;
export const SocialLogin = new SocialLoginClient();
