#!/usr/bin/env node
"use strict";
/**
 * Capacitor Hook Script: Configure Dynamic Provider Dependencies
 *
 * This script runs after `npx cap sync` and configures which providers
 * to include based on capacitor.config.ts settings.
 *
 * Environment variables provided by Capacitor:
 * - CAPACITOR_ROOT_DIR: Root directory of the consuming app
 * - CAPACITOR_CONFIG: JSON stringified config object
 * - CAPACITOR_PLATFORM_NAME: Platform name (android, ios, web)
 * - process.cwd(): Plugin root directory
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProviderConfig = getProviderConfig;
exports.configureAndroid = configureAndroid;
exports.configureIOS = configureIOS;
exports.configureWeb = configureWeb;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// Get environment variables
const PLUGIN_ROOT = process.cwd();
// Not used for now
// const APP_ROOT = process.env.CAPACITOR_ROOT_DIR;
const CONFIG_JSON = process.env.CAPACITOR_CONFIG;
const PLATFORM = process.env.CAPACITOR_PLATFORM_NAME;
// File paths
// Not used for now
// const androidGradlePath = path.join(PLUGIN_ROOT, 'android', 'build.gradle');
const gradlePropertiesPath = path.join(PLUGIN_ROOT, 'android', 'gradle.properties');
const podspecPath = path.join(PLUGIN_ROOT, 'CapgoCapacitorSocialLogin.podspec');
const packageSwiftPath = path.join(PLUGIN_ROOT, 'Package.swift');
// Default provider configuration (backward compatible)
const defaultProviders = {
    google: 'implementation',
    facebook: 'implementation',
    apple: 'implementation',
    twitter: 'implementation',
};
/**
 * 0 - Error
 * 1 - Warning
 * 2 - Info
 * 3 - Success
 */
let logLevel = 3;
// ============================================================================
// Common: Logging Utilities
// ============================================================================
/**
 * ANSI color codes for terminal output
 */
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m',
    gray: '\x1b[90m',
};
/**
 * Capacitor-style colored logging with emojis
 */
function log(message, emoji = '', color = '') {
    const emojiPart = emoji ? `${emoji} ` : '';
    const colorCode = color || colors.reset;
    const resetCode = color ? colors.reset : '';
    console.log(`${colorCode}${emojiPart}${message}${resetCode}`);
}
function logError(message) {
    if (logLevel >= 0) {
        log(message, '✖', colors.red);
    }
}
function logWarning(message) {
    if (logLevel >= 1) {
        log(message, '⚠', colors.yellow);
    }
}
function logInfo(message) {
    if (logLevel >= 2) {
        log(message, 'ℹ', colors.blue);
    }
}
function logSuccess(message) {
    if (logLevel >= 3) {
        log(message, '✔', colors.green);
    }
}
/**
 * Log provider configuration status
 */
function logProviderConfig(providerConfig) {
    if (logLevel < 3) {
        return;
    }
    log('\nProvider configuration:', '', colors.bright);
    const providers = ['google', 'facebook', 'apple', 'twitter'];
    for (const provider of providers) {
        const config = providerConfig[provider];
        const isEnabled = config === 'implementation';
        const providerName = provider.charAt(0).toUpperCase() + provider.slice(1);
        if (isEnabled) {
            // Enabled - green checkmark
            console.log(`  ${colors.green}✔${colors.reset} ${colors.bright}${providerName}${colors.reset}: ${colors.green}enabled${colors.reset}`);
        }
        else {
            // Disabled - red cross
            console.log(`  ${colors.red}✖${colors.reset} ${colors.bright}${providerName}${colors.reset}: ${colors.red}disabled${colors.reset}`);
        }
    }
    console.log('');
}
// ============================================================================
// Common: Configuration Parsing
// ============================================================================
/**
 * Parse provider configuration from Capacitor config
 * Supports: true = implementation, false = compileOnly
 */
function getProviderConfig() {
    try {
        if (!CONFIG_JSON) {
            logWarning('No CAPACITOR_CONFIG found, using defaults');
            return defaultProviders;
        }
        const config = JSON.parse(CONFIG_JSON);
        logLevel = config.plugins?.SocialLogin?.logLevel ?? 3;
        const providerConfig = config.plugins?.SocialLogin?.providers || defaultProviders;
        // Normalize config: convert true to 'implementation', false to 'compileOnly'
        const normalized = {};
        for (const [provider, value] of Object.entries(providerConfig)) {
            if (value === true) {
                normalized[provider] = 'implementation';
            }
            else if (value === false) {
                normalized[provider] = 'compileOnly';
            }
            else {
                // Legacy support: if someone passes a string, use it as-is
                normalized[provider] = value;
            }
        }
        // Merge with defaults for missing providers
        return { ...defaultProviders, ...normalized };
    }
    catch (error) {
        logError(`Error parsing config: ${error.message}`);
        return defaultProviders;
    }
}
// ============================================================================
// Android: Gradle Configuration
// ============================================================================
/**
 * Write gradle.properties file for Android
 * Injects SocialLogin properties while preserving existing content
 */
function configureAndroid(providerConfig) {
    logInfo('Configuring Android dependencies...');
    try {
        // Read existing gradle.properties if it exists
        let existingContent = '';
        if (fs.existsSync(gradlePropertiesPath)) {
            existingContent = fs.readFileSync(gradlePropertiesPath, 'utf8');
        }
        // Remove existing SocialLogin properties (if any)
        const lines = existingContent.split('\n');
        const filteredLines = [];
        let inSocialLoginSection = false;
        let lastWasEmpty = false;
        for (const line of lines) {
            // Check if this is a SocialLogin property or comment
            if (line.trim().startsWith('# SocialLogin') ||
                line.trim().startsWith('socialLogin.') ||
                line.trim() === '# Generated by SocialLogin hook script') {
                inSocialLoginSection = true;
                continue; // Skip this line
            }
            // If we were in SocialLogin section and hit a non-empty line, we're done
            if (inSocialLoginSection && line.trim() !== '') {
                inSocialLoginSection = false;
            }
            // Add non-SocialLogin lines, but avoid multiple consecutive empty lines
            if (!inSocialLoginSection) {
                if (line.trim() === '') {
                    if (!lastWasEmpty) {
                        filteredLines.push(line);
                        lastWasEmpty = true;
                    }
                }
                else {
                    filteredLines.push(line);
                    lastWasEmpty = false;
                }
            }
        }
        // Build new SocialLogin properties section
        const socialLoginProperties = [];
        socialLoginProperties.push('');
        socialLoginProperties.push('# SocialLogin Provider Dependencies (auto-generated)');
        socialLoginProperties.push('# Generated by SocialLogin hook script');
        for (const [provider, value] of Object.entries(providerConfig)) {
            const dependencyType = value === 'compileOnly' ? 'compileOnly' : 'implementation';
            const include = dependencyType === 'compileOnly' ? 'false' : 'true';
            socialLoginProperties.push(`socialLogin.${provider}.include=${include}`);
            socialLoginProperties.push(`socialLogin.${provider}.dependencyType=${dependencyType}`);
        }
        // Combine: existing content + new SocialLogin properties
        const newContent = filteredLines.join('\n') + '\n' + socialLoginProperties.join('\n') + '\n';
        fs.writeFileSync(gradlePropertiesPath, newContent, 'utf8');
        logSuccess('Updated gradle.properties');
    }
    catch (error) {
        logError(`Error updating gradle.properties: ${error.message}`);
    }
}
function applyDependencyReplacements(content, replacements) {
    let updatedContent = content;
    let modified = false;
    for (const replacement of replacements) {
        if (replacement.old.test(updatedContent)) {
            const before = updatedContent;
            updatedContent = updatedContent.replace(replacement.old, replacement.new);
            if (before !== updatedContent) {
                modified = true;
            }
        }
    }
    return { content: updatedContent, modified };
}
function getPodspecReplacements(providerConfig) {
    const podspecTrailingComment = '([ \\t]*#[^\\r\\n]*)?';
    return [
        {
            // Google SignIn - handle both active and commented (including existing disabled comments)
            old: new RegExp(`(#[ \\t]*)?s\\.dependency\\s+'GoogleSignIn',\\s*'~>\\s*9\\.0\\.0'${podspecTrailingComment}`),
            new: providerConfig.google === 'implementation'
                ? `s.dependency 'GoogleSignIn', '~> 9.0.0'`
                : `# s.dependency 'GoogleSignIn', '~> 9.0.0'  # Disabled via config (compileOnly)`,
        },
        {
            // Facebook Core - handle both active and commented (including existing disabled comments)
            old: new RegExp(`(#[ \\t]*)?s\\.dependency\\s+'FBSDKCoreKit',\\s*'~>\\s*18\\.0'${podspecTrailingComment}`),
            new: providerConfig.facebook === 'implementation'
                ? `s.dependency 'FBSDKCoreKit', '~> 18.0'`
                : `# s.dependency 'FBSDKCoreKit', '~> 18.0'  # Disabled via config (compileOnly)`,
        },
        {
            // Facebook Login - handle both active and commented (including existing disabled comments)
            old: new RegExp(`(#[ \\t]*)?s\\.dependency\\s+'FBSDKLoginKit',\\s*'~>\\s*18\\.0'${podspecTrailingComment}`),
            new: providerConfig.facebook === 'implementation'
                ? `s.dependency 'FBSDKLoginKit', '~> 18.0'`
                : `# s.dependency 'FBSDKLoginKit', '~> 18.0'  # Disabled via config (compileOnly)`,
        },
    ];
}
function getPackageSwiftReplacements(providerConfig) {
    const swiftCommentPrefix = '(?:\\/\\/[ \\t]*)*';
    const swiftTrailingComment = '(?:[ \\t]*\\/\\/[^\\r\\n]*)?';
    return [
        {
            old: new RegExp(`${swiftCommentPrefix}\\.package\\(url:\\s*"https:\\/\\/github\\.com\\/facebook\\/facebook-ios-sdk\\.git",\\s*\\.upToNextMajor\\(from:\\s*"[^"]+"\\)\\),${swiftTrailingComment}`),
            new: providerConfig.facebook === 'implementation'
                ? `.package(url: "https://github.com/facebook/facebook-ios-sdk.git", .upToNextMajor(from: "18.0.3")),`
                : `// .package(url: "https://github.com/facebook/facebook-ios-sdk.git", .upToNextMajor(from: "18.0.3")),  // Disabled via config (compileOnly)`,
        },
        {
            old: new RegExp(`${swiftCommentPrefix}\\.package\\(url:\\s*"https:\\/\\/github\\.com\\/google\\/GoogleSignIn-iOS\\.git",\\s*\\.upToNextMajor\\(from:\\s*"[^"]+"\\)\\),${swiftTrailingComment}`),
            new: providerConfig.google === 'implementation'
                ? `.package(url: "https://github.com/google/GoogleSignIn-iOS.git", .upToNextMajor(from: "9.0.0")),`
                : `// .package(url: "https://github.com/google/GoogleSignIn-iOS.git", .upToNextMajor(from: "9.0.0")),  // Disabled via config (compileOnly)`,
        },
        {
            old: new RegExp(`${swiftCommentPrefix}\\.product\\(name:\\s*"FacebookCore",\\s*package:\\s*"facebook-ios-sdk"\\),${swiftTrailingComment}`),
            new: providerConfig.facebook === 'implementation'
                ? `.product(name: "FacebookCore", package: "facebook-ios-sdk"),`
                : `// .product(name: "FacebookCore", package: "facebook-ios-sdk"),  // Disabled via config (compileOnly)`,
        },
        {
            old: new RegExp(`${swiftCommentPrefix}\\.product\\(name:\\s*"FacebookLogin",\\s*package:\\s*"facebook-ios-sdk"\\),${swiftTrailingComment}`),
            new: providerConfig.facebook === 'implementation'
                ? `.product(name: "FacebookLogin", package: "facebook-ios-sdk"),`
                : `// .product(name: "FacebookLogin", package: "facebook-ios-sdk"),  // Disabled via config (compileOnly)`,
        },
        {
            old: new RegExp(`${swiftCommentPrefix}\\.product\\(name:\\s*"GoogleSignIn",\\s*package:\\s*"GoogleSignIn-iOS"\\),${swiftTrailingComment}`),
            new: providerConfig.google === 'implementation'
                ? `.product(name: "GoogleSignIn", package: "GoogleSignIn-iOS"),`
                : `// .product(name: "GoogleSignIn", package: "GoogleSignIn-iOS"),  // Disabled via config (compileOnly)`,
        },
    ];
}
/**
 * Modify Podspec and Package.swift for iOS conditional dependencies
 */
function configureIOS(providerConfig) {
    logInfo('Configuring iOS dependencies...');
    let success = true;
    try {
        const podspecResult = applyDependencyReplacements(fs.readFileSync(podspecPath, 'utf8'), getPodspecReplacements(providerConfig));
        if (podspecResult.modified) {
            fs.writeFileSync(podspecPath, podspecResult.content, 'utf8');
            logSuccess('Modified podspec');
        }
        else {
            logInfo('Podspec already up to date');
        }
    }
    catch (error) {
        logError(`Error modifying podspec: ${error.message}`);
        success = false;
    }
    if (!fs.existsSync(packageSwiftPath)) {
        logError('Package.swift not found; Swift Package Manager configuration is required');
        return false;
    }
    try {
        const packageSwiftResult = applyDependencyReplacements(fs.readFileSync(packageSwiftPath, 'utf8'), getPackageSwiftReplacements(providerConfig));
        if (packageSwiftResult.modified) {
            fs.writeFileSync(packageSwiftPath, packageSwiftResult.content, 'utf8');
            logSuccess('Modified Package.swift');
        }
        else {
            logInfo('Package.swift already up to date');
        }
    }
    catch (error) {
        logError(`Error modifying Package.swift: ${error.message}`);
        success = false;
    }
    return success;
}
// ============================================================================
// Web: No Configuration Needed
// ============================================================================
/**
 * Web platform doesn't need native dependency configuration
 */
function configureWeb() {
    logInfo('Skipping conditional dependency compilation for web platform');
    logInfo('Web platform uses JavaScript dependencies managed by npm/bundler');
}
// ============================================================================
// Main Execution
// ============================================================================
/**
 * Main execution
 */
function main() {
    let configurationSucceeded = true;
    // Route to platform-specific configuration
    switch (PLATFORM) {
        case 'android':
            // eslint-disable-next-line no-case-declarations
            const androidConfig = getProviderConfig();
            logInfo('Configuring dynamic provider dependencies for SocialLogin');
            logProviderConfig(androidConfig);
            configureAndroid(androidConfig);
            break;
        case 'ios':
            // eslint-disable-next-line no-case-declarations
            const iosConfig = getProviderConfig();
            logInfo('Configuring dynamic provider dependencies for SocialLogin');
            logProviderConfig(iosConfig);
            configurationSucceeded = configureIOS(iosConfig);
            break;
        case 'web':
            configureWeb();
            break;
        default:
            // If platform is not specified, configure all platforms (backward compatibility)
            // eslint-disable-next-line no-case-declarations
            const defaultConfig = getProviderConfig();
            logInfo('Configuring dynamic provider dependencies for SocialLogin');
            logProviderConfig(defaultConfig);
            logWarning(`Unknown platform: ${PLATFORM || 'undefined'}, configuring all platforms`);
            configureAndroid(defaultConfig);
            configurationSucceeded = configureIOS(defaultConfig);
            break;
    }
    if (!configurationSucceeded) {
        logError('Configuration failed\n');
        process.exit(1);
    }
    logSuccess('Configuration complete\n');
}
// Run if executed directly
if (require.main === module) {
    main();
}
