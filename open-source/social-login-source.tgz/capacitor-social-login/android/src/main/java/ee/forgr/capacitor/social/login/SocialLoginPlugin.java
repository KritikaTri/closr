package ee.forgr.capacitor.social.login;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import androidx.activity.result.ActivityResult;
import androidx.browser.customtabs.CustomTabsIntent;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import ee.forgr.capacitor.social.login.helpers.DependencyAvailabilityChecker;
import ee.forgr.capacitor.social.login.helpers.SocialProvider;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

@CapacitorPlugin(name = "SocialLogin")
public class SocialLoginPlugin extends Plugin {

    private final String pluginVersion = "8.7.5";

    public static String LOG_TAG = "CapgoSocialLogin";
    private static final String USER_CANCELLED_CODE = "USER_CANCELLED";
    private static final long OPEN_AUTH_SESSION_TIMEOUT_MS = 600_000L;
    public HashMap<String, SocialProvider> socialProviderHashMap = new HashMap<>();

    private PluginCall openSecureWindowSavedCall;
    private String openSecureWindowRedirectUri;
    private PluginCall openAuthSessionSavedCall;
    private String openAuthSessionCallbackScheme;
    private String openAuthSessionExpectedCallbackPrefix;
    private boolean openAuthSessionPaused;
    private long openAuthSessionLaunchTimeMs;
    private Handler openAuthSessionHandler;
    private Runnable openAuthSessionTimeoutRunnable;
    private Uri pendingOAuth2RedirectUri;

    private boolean isAnotherAuthBrowserSessionInProgress() {
        if (openAuthSessionSavedCall != null || openSecureWindowSavedCall != null) {
            return true;
        }
        SocialProvider oauth2 = socialProviderHashMap.get("oauth2");
        if (oauth2 instanceof OAuth2Provider) {
            return ((OAuth2Provider) oauth2).getPendingCall() != null;
        }
        return false;
    }

    private boolean rejectIfAnotherAuthBrowserSessionPending(PluginCall call) {
        if (isAnotherAuthBrowserSessionInProgress()) {
            call.reject("Another auth session is already in progress");
            return true;
        }
        return false;
    }

    private void cancelOpenAuthSessionTimeout() {
        if (openAuthSessionHandler != null && openAuthSessionTimeoutRunnable != null) {
            openAuthSessionHandler.removeCallbacks(openAuthSessionTimeoutRunnable);
        }
        openAuthSessionTimeoutRunnable = null;
    }

    private void clearOpenAuthSessionState() {
        cancelOpenAuthSessionTimeout();
        openAuthSessionSavedCall = null;
        openAuthSessionCallbackScheme = null;
        openAuthSessionExpectedCallbackPrefix = null;
        openAuthSessionPaused = false;
        openAuthSessionLaunchTimeMs = 0L;
    }

    static String resolveOpenAuthSessionExpectedCallbackPrefix(String authorizeUrl, String callbackURLScheme) {
        if (authorizeUrl != null && !authorizeUrl.isEmpty()) {
            try {
                String redirectUri = extractRedirectUriFromAuthorizeQuery(authorizeUrl);
                if (redirectUri == null || redirectUri.isEmpty()) {
                    redirectUri = Uri.parse(authorizeUrl).getQueryParameter("redirect_uri");
                }
                if (redirectUri != null && !redirectUri.isEmpty()) {
                    return redirectUri;
                }
            } catch (Exception ignored) {
                // fall back to scheme prefix below
            }
        }
        if (callbackURLScheme == null || callbackURLScheme.isEmpty()) {
            return null;
        }
        return callbackURLScheme + ":";
    }

    static boolean matchesOpenAuthSessionCallback(String callbackUrl, String expectedPrefix, String callbackURLScheme) {
        if (callbackUrl == null || expectedPrefix == null || expectedPrefix.isEmpty()) {
            return false;
        }
        if (callbackURLScheme != null && expectedPrefix.equals(callbackURLScheme + ":")) {
            String schemePrefix = callbackURLScheme + ":";
            return (
                callbackUrl.regionMatches(true, 0, schemePrefix, 0, schemePrefix.length()) && callbackUrl.length() > schemePrefix.length()
            );
        }
        return (
            callbackUrl.equals(expectedPrefix) ||
            callbackUrl.startsWith(expectedPrefix + "?") ||
            callbackUrl.startsWith(expectedPrefix + "&") ||
            callbackUrl.startsWith(expectedPrefix + "#")
        );
    }

    private static String extractRedirectUriFromAuthorizeQuery(String authorizeUrl) {
        int queryStart = authorizeUrl.indexOf('?');
        if (queryStart < 0 || queryStart >= authorizeUrl.length() - 1) {
            return null;
        }
        String query = authorizeUrl.substring(queryStart + 1);
        int fragmentStart = query.indexOf('#');
        if (fragmentStart >= 0) {
            query = query.substring(0, fragmentStart);
        }
        for (String part : query.split("&")) {
            int equals = part.indexOf('=');
            if (equals <= 0) {
                continue;
            }
            if (!"redirect_uri".equals(part.substring(0, equals))) {
                continue;
            }
            return URLDecoder.decode(part.substring(equals + 1), StandardCharsets.UTF_8);
        }
        return null;
    }

    private void scheduleOpenAuthSessionTimeout() {
        if (openAuthSessionHandler == null) {
            openAuthSessionHandler = new Handler(Looper.getMainLooper());
        }
        cancelOpenAuthSessionTimeout();
        openAuthSessionTimeoutRunnable = () -> {
            if (openAuthSessionSavedCall != null) {
                openAuthSessionSavedCall.reject("The sign-in flow timed out", USER_CANCELLED_CODE);
                clearOpenAuthSessionState();
            }
        };
        openAuthSessionHandler.postDelayed(openAuthSessionTimeoutRunnable, OPEN_AUTH_SESSION_TIMEOUT_MS);
    }

    @PluginMethod
    public void initialize(PluginCall call) {
        // Set plugin instance for config access
        DependencyAvailabilityChecker.setPluginInstance(this);

        JSObject apple = call.getObject("apple");
        if (apple != null) {
            // Check if Apple dependencies are available
            if (!DependencyAvailabilityChecker.isProviderAvailable("apple")) {
                call.reject(
                    "Apple Sign-In provider is disabled. " +
                        "Dependencies are not available. Ensure CustomTabs dependencies are included in your app's build.gradle"
                );
                return;
            }

            String androidAppleClientId = apple.getString("clientId");
            if (androidAppleClientId == null || androidAppleClientId.isEmpty()) {
                call.reject("apple.android.clientId is null or empty");
                return;
            }

            boolean useProperTokenExchange = apple.has("useProperTokenExchange") ? apple.getBool("useProperTokenExchange") : false;
            boolean useBroadcastChannel = apple.has("useBroadcastChannel") ? apple.getBool("useBroadcastChannel") : false;
            String androidAppleRedirect = apple.getString("redirectUrl");
            if (shouldRejectMissingAppleRedirectUrl(androidAppleRedirect, useBroadcastChannel)) {
                call.reject("apple.android.redirectUrl is null or empty");
                return;
            }

            AppleProvider appleProvider = new AppleProvider(
                androidAppleRedirect,
                androidAppleClientId,
                this.getActivity(),
                this.getContext(),
                useProperTokenExchange,
                useBroadcastChannel
            );

            appleProvider.initialize();
            this.socialProviderHashMap.put("apple", appleProvider);
        }

        JSObject google = call.getObject("google");
        if (google != null) {
            GoogleProvider googleProvider = new GoogleProvider(this.getActivity(), this.getContext());
            String googleClientId = google.getString("webClientId");
            if (googleClientId == null || googleClientId.isEmpty()) {
                call.reject("google.clientId is null or empty");
                return;
            }
            String hostedDomain = google.getString("hostedDomain");
            String modestr = google.getString("mode", "online");
            GoogleProvider.GoogleProviderLoginType mode = null;
            switch (modestr) {
                case "online":
                    mode = GoogleProvider.GoogleProviderLoginType.ONLINE;
                    break;
                case "offline":
                    mode = GoogleProvider.GoogleProviderLoginType.OFFLINE;
                    break;
                default:
                    call.reject("google.mode != (online || offline)");
                    return;
            }
            googleProvider.initialize(googleClientId, mode, hostedDomain);
            this.socialProviderHashMap.put("google", googleProvider);
        }

        JSObject facebook = call.getObject("facebook");
        if (facebook != null) {
            // Check if Facebook dependencies are available
            if (!DependencyAvailabilityChecker.isProviderAvailable("facebook")) {
                call.reject(
                    "Facebook provider is disabled. " +
                        "Dependencies are not available. Ensure Facebook Login dependencies are included in your app's build.gradle"
                );
                return;
            }

            String facebookAppId = facebook.getString("appId");
            String facebookClientToken = facebook.getString("clientToken");
            if (facebookAppId == null || facebookAppId.isEmpty()) {
                call.reject("facebook.appId is null or empty");
                return;
            }
            if (facebookClientToken == null || facebookClientToken.isEmpty()) {
                call.reject("facebook.clientToken is null or empty");
                return;
            }
            FacebookProvider facebookProvider = new FacebookProvider(this.getActivity());
            try {
                facebookProvider.initialize(facebook);
                this.socialProviderHashMap.put("facebook", facebookProvider);
            } catch (Exception e) {
                call.reject("Failed to initialize Facebook provider: " + e.getMessage());
                return;
            }
        }

        JSObject twitter = call.getObject("twitter");
        if (twitter != null) {
            // Check if Twitter dependencies are available
            if (!DependencyAvailabilityChecker.isProviderAvailable("twitter")) {
                call.reject("Twitter provider is disabled via configuration.");
                return;
            }

            String twitterClientId = twitter.getString("clientId");
            String twitterRedirect = twitter.getString("redirectUrl");
            if (twitterClientId == null || twitterClientId.isEmpty()) {
                call.reject("twitter.clientId is null or empty");
                return;
            }
            if (twitterRedirect == null || twitterRedirect.isEmpty()) {
                call.reject("twitter.redirectUrl is null or empty");
                return;
            }
            TwitterProvider twitterProvider = new TwitterProvider(this.getActivity(), this.getContext());
            try {
                twitterProvider.initialize(twitter);
                this.socialProviderHashMap.put("twitter", twitterProvider);
            } catch (JSONException e) {
                call.reject("Failed to initialize Twitter provider: " + e.getMessage());
                return;
            }
        }

        JSObject telegram = call.getObject("telegram");
        if (telegram != null) {
            if (!DependencyAvailabilityChecker.isProviderAvailable("telegram")) {
                call.reject("Telegram provider is disabled in capacitor.config");
                return;
            }
            String botId = telegram.getString("botId");
            if (botId == null || botId.isEmpty()) {
                call.reject("telegram.botId is null or empty");
                return;
            }
            TelegramProvider telegramProvider = new TelegramProvider(this.getActivity(), this.getContext());
            try {
                telegramProvider.initialize(telegram);
                this.socialProviderHashMap.put("telegram", telegramProvider);
            } catch (JSONException e) {
                call.reject("Failed to initialize Telegram provider: " + e.getMessage());
                return;
            }
        }

        JSObject oauth2 = call.getObject("oauth2");
        if (oauth2 != null && oauth2.length() > 0) {
            // oauth2 is now a map of providerId -> config: { "github": {...}, "azure": {...} }
            OAuth2Provider oauth2Provider = new OAuth2Provider(this.getActivity(), this.getContext());
            try {
                java.util.List<String> errors = oauth2Provider.initializeProviders(oauth2);
                if (!errors.isEmpty()) {
                    call.reject(String.join(", ", errors));
                    return;
                }
                this.socialProviderHashMap.put("oauth2", oauth2Provider);
                oauth2Provider.setAuthBrowserSessionGuard(this::isAnotherAuthBrowserSessionInProgress);
                oauth2Provider.setActivityLauncher((intent, requestCode) -> {
                    PluginCall loginCall = oauth2Provider.getPendingCall();
                    if (loginCall != null) {
                        startActivityForResult(loginCall, intent, "handleOAuth2ActivityResult");
                    } else {
                        Log.e(LOG_TAG, "OAuth2 activityLauncher fired but pendingCall is null, cannot route result");
                    }
                });
                // Replay a redirect that arrived before initialize (cold start / process death)
                boolean handledRedirect = false;
                if (pendingOAuth2RedirectUri != null) {
                    Uri buffered = pendingOAuth2RedirectUri;
                    pendingOAuth2RedirectUri = null;
                    handledRedirect = oauth2Provider.handleRedirectUri(buffered);
                }
                // If handleOnResume ran before initialize, persisted Custom Tabs state may still be
                // present with no buffered redirect — restore then cancel/clear the orphaned session
                // (or complete via activity.getIntent() if the redirect is attached there).
                if (!handledRedirect && oauth2Provider.restorePersistedCustomTabsState()) {
                    oauth2Provider.handleUserReturnedWithoutCallback();
                }
            } catch (JSONException e) {
                call.reject("Failed to initialize OAuth2 provider: " + e.getMessage());
                return;
            }
        }

        call.resolve();
    }

    static boolean shouldRejectMissingAppleRedirectUrl(String redirectUrl, boolean useBroadcastChannel) {
        return !useBroadcastChannel && (redirectUrl == null || redirectUrl.isEmpty());
    }

    @PluginMethod
    public void login(PluginCall call) {
        String providerStr = call.getString("provider", "");
        if (providerStr == null || providerStr.isEmpty()) {
            call.reject("provider not provided");
        }

        JSONObject options = call.getObject("options", new JSObject());

        SocialProvider provider = this.socialProviderHashMap.get(providerStr);
        if (provider == null) {
            // Check if provider is disabled (dependencies not available)
            if (!DependencyAvailabilityChecker.isProviderAvailable(providerStr)) {
                call.reject(
                    String.format(
                        "Provider '%s' is disabled. Dependencies are not available. " +
                            "Ensure required dependencies are included in your app's build.gradle",
                        providerStr
                    )
                );
            } else {
                call.reject(String.format("Cannot find provider '%s'. Provider was not initialized.", providerStr));
            }
            return;
        }

        if (rejectIfAnotherAuthBrowserSessionPending(call)) {
            return;
        }

        provider.login(call, options);
    }

    @PluginMethod
    public void logout(PluginCall call) {
        String providerStr = call.getString("provider", "");
        if (providerStr == null || providerStr.isEmpty()) {
            call.reject("provider not provided");
        }

        SocialProvider provider = this.socialProviderHashMap.get(providerStr);
        if (provider == null) {
            // Check if provider is disabled (dependencies not available)
            if (!DependencyAvailabilityChecker.isProviderAvailable(providerStr)) {
                call.reject(
                    String.format(
                        "Provider '%s' is disabled. Dependencies are not available. " +
                            "Ensure required dependencies are included in your app's build.gradle",
                        providerStr
                    )
                );
            } else {
                call.reject(String.format("Cannot find provider '%s'. Provider was not initialized.", providerStr));
            }
            return;
        }

        provider.logout(call);
    }

    @PluginMethod
    public void getAuthorizationCode(PluginCall call) {
        String providerStr = call.getString("provider", "");
        if (providerStr == null || providerStr.isEmpty()) {
            call.reject("provider not provided");
        }

        SocialProvider provider = this.socialProviderHashMap.get(providerStr);
        if (provider == null) {
            // Check if provider is disabled (dependencies not available)
            if (!DependencyAvailabilityChecker.isProviderAvailable(providerStr)) {
                call.reject(
                    String.format(
                        "Provider '%s' is disabled. Dependencies are not available. " +
                            "Ensure required dependencies are included in your app's build.gradle",
                        providerStr
                    )
                );
            } else {
                call.reject(String.format("Cannot find provider '%s'. Provider was not initialized.", providerStr));
            }
            return;
        }

        provider.getAuthorizationCode(call);
    }

    @PluginMethod
    public void isLoggedIn(PluginCall call) {
        String providerStr = call.getString("provider", "");
        if (providerStr == null || providerStr.isEmpty()) {
            call.reject("provider not provided");
        }

        SocialProvider provider = this.socialProviderHashMap.get(providerStr);
        if (provider == null) {
            // Check if provider is disabled (dependencies not available)
            if (!DependencyAvailabilityChecker.isProviderAvailable(providerStr)) {
                call.reject(
                    String.format(
                        "Provider '%s' is disabled. Dependencies are not available. " +
                            "Ensure required dependencies are included in your app's build.gradle",
                        providerStr
                    )
                );
            } else {
                call.reject(String.format("Cannot find provider '%s'. Provider was not initialized.", providerStr));
            }
            return;
        }

        provider.isLoggedIn(call);
    }

    @PluginMethod
    public void refresh(PluginCall call) {
        String providerStr = call.getString("provider", "");
        if (providerStr == null || providerStr.isEmpty()) {
            call.reject("provider not provided");
        }

        SocialProvider provider = this.socialProviderHashMap.get(providerStr);
        if (provider == null) {
            // Check if provider is disabled (dependencies not available)
            if (!DependencyAvailabilityChecker.isProviderAvailable(providerStr)) {
                call.reject(
                    String.format(
                        "Provider '%s' is disabled. Dependencies are not available. " +
                            "Ensure required dependencies are included in your app's build.gradle",
                        providerStr
                    )
                );
            } else {
                call.reject(String.format("Cannot find provider '%s'. Provider was not initialized.", providerStr));
            }
            return;
        }

        provider.refresh(call);
    }

    @PluginMethod
    public void providerSpecificCall(PluginCall call) {
        String customCall = call.getString("call");
        if (customCall == null || customCall.isEmpty()) {
            call.reject("Call is required");
            return;
        }

        switch (customCall) {
            case "facebook#getProfile":
                JSObject options = call.getObject("options", new JSObject());
                if (options == null) {
                    call.reject("Options are required");
                    return;
                }

                JSONArray fieldsArray = null;
                try {
                    fieldsArray = options.getJSONArray("fields");
                } catch (JSONException e) {
                    call.reject("Fields array is required");
                    return;
                }

                SocialProvider provider = this.socialProviderHashMap.get("facebook");
                if (provider == null || !(provider instanceof FacebookProvider)) {
                    call.reject("Facebook provider not initialized");
                    return;
                }

                ((FacebookProvider) provider).getProfile(fieldsArray, call);
                break;
            case "google#createRestoreCredential":
            case "google#getRestoreCredential":
            case "google#clearRestoreCredential":
                SocialProvider googleProvider = this.socialProviderHashMap.get("google");
                if (googleProvider == null || !(googleProvider instanceof GoogleProvider)) {
                    call.reject("Google provider not initialized");
                    return;
                }
                GoogleProvider google = (GoogleProvider) googleProvider;
                switch (customCall) {
                    case "google#createRestoreCredential":
                        google.createRestoreCredential(call);
                        break;
                    case "google#getRestoreCredential":
                        google.getRestoreCredential(call);
                        break;
                    case "google#clearRestoreCredential":
                        google.clearRestoreCredential(call);
                        break;
                    default:
                        call.reject("Invalid Google provider call");
                }
                break;
            default:
                call.reject(
                    "Invalid call. Supported calls: facebook#getProfile, " +
                        "google#createRestoreCredential, google#getRestoreCredential, google#clearRestoreCredential"
                );
        }
    }

    @ActivityCallback
    private void handleOAuth2ActivityResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            Log.e(LOG_TAG, "OAuth2 activity result: saved call is null");
            return;
        }

        SocialProvider oauth2Provider = socialProviderHashMap.get("oauth2");
        if (!(oauth2Provider instanceof OAuth2Provider)) {
            call.reject("OAuth2 provider not found");
            return;
        }

        OAuth2Provider p = (OAuth2Provider) oauth2Provider;
        if (p.getPendingCall() == null) {
            p.setPendingCall(call);
        }

        Intent data = result.getData();
        int resultCode = result.getResultCode();
        p.handleActivityResult(OAuth2Provider.REQUEST_CODE, resultCode, data);
    }

    public void handleGoogleLoginIntent(int requestCode, Intent intent) {
        try {
            SocialProvider provider = socialProviderHashMap.get("google");
            if (!(provider instanceof GoogleProvider)) {
                Log.e(SocialLoginPlugin.LOG_TAG, "Provider is not a Google provider (could be null)");
                return;
            }
            ((GoogleProvider) provider).handleAuthorizationIntent(requestCode, intent);
        } catch (Throwable t) {
            Log.e(SocialLoginPlugin.LOG_TAG, "Cannot handle Google login intent");
        }
    }

    public void handleAppleLoginIntent(Intent intent) {
        try {
            SocialProvider provider = socialProviderHashMap.get("apple");
            if (!(provider instanceof AppleProvider)) {
                Log.e(SocialLoginPlugin.LOG_TAG, "Provider is not an apple provider (could be null)");
                return;
            }
            ((AppleProvider) provider).handleIntent(intent);
        } catch (Throwable t) {
            Log.e(SocialLoginPlugin.LOG_TAG, "Cannot handle apple login intent");
        }
    }

    @Override
    protected void handleOnActivityResult(int requestCode, int resultCode, Intent data) {
        super.handleOnActivityResult(requestCode, resultCode, data);

        Log.d(LOG_TAG, "SocialLoginPlugin.handleOnActivityResult called (legacy fallback path)");

        // Handle Facebook login result
        SocialProvider facebookProvider = socialProviderHashMap.get("facebook");
        if (facebookProvider instanceof FacebookProvider) {
            boolean handled = ((FacebookProvider) facebookProvider).handleOnActivityResult(requestCode, resultCode, data);
            if (handled) {
                Log.d(LOG_TAG, "Facebook activity result handled");
                return;
            }
        }

        SocialProvider twitterProvider = socialProviderHashMap.get("twitter");
        if (twitterProvider instanceof TwitterProvider) {
            boolean handled = ((TwitterProvider) twitterProvider).handleActivityResult(requestCode, resultCode, data);
            if (handled) {
                Log.d(LOG_TAG, "Twitter activity result handled");
                return;
            }
        }

        SocialProvider telegramProvider = socialProviderHashMap.get("telegram");
        if (telegramProvider instanceof TelegramProvider) {
            boolean handled = ((TelegramProvider) telegramProvider).handleActivityResult(requestCode, resultCode, data);
            if (handled) {
                Log.d(LOG_TAG, "Telegram activity result handled");
                return;
            }
        }

        SocialProvider oauth2Provider = socialProviderHashMap.get("oauth2");
        if (oauth2Provider instanceof OAuth2Provider) {
            boolean handled = ((OAuth2Provider) oauth2Provider).handleActivityResult(requestCode, resultCode, data);
            if (handled) {
                Log.d(LOG_TAG, "OAuth2 activity result handled");
                return;
            }
        }

        // Handle other providers' activity results if needed
        Log.d(LOG_TAG, "Activity result not handled by any provider");
    }

    @PluginMethod
    public void getPluginVersion(final PluginCall call) {
        try {
            final JSObject ret = new JSObject();
            ret.put("version", this.pluginVersion);
            call.resolve(ret);
        } catch (final Exception e) {
            call.reject("Could not get plugin version", e);
        }
    }

    @PluginMethod
    public void refreshToken(final PluginCall call) {
        String provider = call.getString("provider", "");
        if (!"oauth2".equals(provider)) {
            call.reject("refreshToken is only implemented for oauth2");
            return;
        }
        String providerId = call.getString("providerId");
        if (providerId == null || providerId.isEmpty()) {
            call.reject("providerId is required for oauth2 refreshToken");
            return;
        }
        SocialProvider p = socialProviderHashMap.get("oauth2");
        if (!(p instanceof OAuth2Provider)) {
            call.reject("OAuth2 provider is not initialized");
            return;
        }
        String refreshToken = call.getString("refreshToken");
        JSObject additionalParams = call.getObject("additionalParameters");
        ((OAuth2Provider) p).refreshTokenRaw(call, providerId, refreshToken, additionalParams);
    }

    @PluginMethod
    public void handleRedirectCallback(final PluginCall call) {
        call.reject("handleRedirectCallback is only available on web");
    }

    @PluginMethod
    public void decodeIdToken(final PluginCall call) {
        String idToken = call.getString("idToken");
        if (idToken == null || idToken.isEmpty()) {
            idToken = call.getString("token");
        }
        if (idToken == null || idToken.isEmpty()) {
            call.reject("idToken (or token) is required");
            return;
        }
        try {
            JSONObject claims = decodeJwtClaims(idToken);
            JSObject ret = new JSObject();
            ret.put("claims", claims);
            call.resolve(ret);
        } catch (JSONException e) {
            call.reject("Invalid JWT");
        } catch (Exception e) {
            call.reject("Failed to decode idToken", e);
        }
    }

    static JSONObject decodeJwtClaims(String idToken) throws JSONException {
        byte[] decoded = Base64.decode(getJwtPayloadSegment(idToken), Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
        String json = new String(decoded, StandardCharsets.UTF_8);
        return new JSONObject(json);
    }

    static JSONObject decodeJwtHeaderObject(String idToken) throws JSONException {
        byte[] decoded = Base64.decode(getJwtHeaderSegment(idToken), Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
        String headerJson = new String(decoded, StandardCharsets.UTF_8);
        JSONTokener tokener = new JSONTokener(headerJson);
        JSONObject header = new JSONObject(tokener);
        if (tokener.more()) {
            throw new JSONException("Invalid JWT header");
        }
        return header;
    }

    static String getJwtHeaderSegment(String idToken) throws JSONException {
        String[] parts = idToken.split("\\.");
        if (parts.length < 1 || parts[0].isEmpty()) {
            throw new JSONException("Invalid JWT");
        }
        return parts[0];
    }

    /**
     * Returns whether the JWT should be treated as expired for login checks.
     * Matches Auth0 {@code JWT.isExpired(leewaySeconds)} from jwtdecode 2.0.2 (second-truncated clock, exp/iat leeway).
     */
    static boolean isJwtExpired(String idToken, long leewaySeconds) throws JSONException {
        if (leewaySeconds < 0) {
            throw new IllegalArgumentException("The leeway must be a positive value.");
        }
        assertJwtHasThreeParts(idToken);
        decodeJwtHeaderObject(idToken);
        JSONObject claims = decodeJwtClaims(idToken);
        long todayTime = (long) (Math.floor(System.currentTimeMillis() / 1000.0) * 1000);
        Date futureToday = new Date(todayTime + leewaySeconds * 1000L);
        Date pastToday = new Date(todayTime - leewaySeconds * 1000L);
        Date exp = claims.has("exp") ? new Date(claims.getLong("exp") * 1000L) : null;
        Date iat = claims.has("iat") ? new Date(claims.getLong("iat") * 1000L) : null;
        boolean expValid = exp == null || !pastToday.after(exp);
        boolean iatValid = iat == null || !futureToday.before(iat);
        return !expValid || !iatValid;
    }

    static void assertJwtHasThreeParts(String idToken) throws JSONException {
        String[] parts = idToken.split("\\.");
        if (parts.length == 2 && idToken.endsWith(".")) {
            return;
        }
        if (parts.length != 3) {
            throw new JSONException(String.format("The token was expected to have 3 parts, but got %s.", parts.length));
        }
    }

    static String getJwtPayloadSegment(String idToken) throws JSONException {
        String[] parts = idToken.split("\\.");
        if (parts.length < 2) {
            throw new JSONException("Invalid JWT");
        }
        return parts[1];
    }

    // Capacitor's PluginCall.getLong() only reads Java Long values. JS numbers that
    // fit in 32 bits cross the bridge as Integer, so Number coercion is required.
    static Long longOptionFromCall(PluginCall call, String key) {
        if (!call.getData().has(key)) {
            return null;
        }
        Object value = call.getData().opt(key);
        if (value == null || !(value instanceof Number)) {
            return null;
        }
        return ((Number) value).longValue();
    }

    @PluginMethod
    public void getAccessTokenExpirationDate(final PluginCall call) {
        Long expiresAt = longOptionFromCall(call, "accessTokenExpirationDate");
        if (expiresAt == null) {
            call.reject("accessTokenExpirationDate is required");
            return;
        }
        String iso = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX").format(new java.util.Date(expiresAt));
        call.resolve(new JSObject().put("date", iso));
    }

    @PluginMethod
    public void isAccessTokenAvailable(final PluginCall call) {
        String token = call.getString("accessToken");
        boolean ok = token != null && !token.isEmpty();
        call.resolve(new JSObject().put("isAvailable", ok));
    }

    @PluginMethod
    public void isAccessTokenExpired(final PluginCall call) {
        Long expiresAt = longOptionFromCall(call, "accessTokenExpirationDate");
        if (expiresAt == null) {
            call.reject("accessTokenExpirationDate is required");
            return;
        }
        boolean expired = expiresAt <= System.currentTimeMillis();
        call.resolve(new JSObject().put("isExpired", expired));
    }

    @PluginMethod
    public void isRefreshTokenAvailable(final PluginCall call) {
        String token = call.getString("refreshToken");
        boolean ok = token != null && !token.isEmpty();
        call.resolve(new JSObject().put("isAvailable", ok));
    }

    @PluginMethod
    public void openSecureWindow(PluginCall call) {
        String authEndpoint = call.getString("authEndpoint");

        if (authEndpoint == null || authEndpoint.isEmpty()) {
            call.reject("Auth endpoint is required");
            return;
        }

        String redirectUri = call.getString("redirectUri");
        if (redirectUri == null || redirectUri.isEmpty()) {
            call.reject("Redirect URI is required");
            return;
        }

        if (rejectIfAnotherAuthBrowserSessionPending(call)) {
            return;
        }

        openSecureWindowSavedCall = call;
        openSecureWindowRedirectUri = redirectUri;

        try {
            launchCustomTab(authEndpoint);
        } catch (Exception e) {
            openSecureWindowSavedCall = null;
            openSecureWindowRedirectUri = null;
            call.reject("Unable to open browser", e);
        }
    }

    @PluginMethod
    public void openAuthSession(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }

        String callbackURLScheme = call.getString("callbackURLScheme");
        if (callbackURLScheme == null || callbackURLScheme.isEmpty()) {
            call.reject("callbackURLScheme is required");
            return;
        }

        if (rejectIfAnotherAuthBrowserSessionPending(call)) {
            return;
        }

        if (getActivity() == null) {
            call.reject("Activity not available");
            return;
        }

        getActivity().runOnUiThread(() -> startOpenAuthSessionOnMainThread(call, url, callbackURLScheme));
    }

    private void startOpenAuthSessionOnMainThread(PluginCall call, String url, String callbackURLScheme) {
        if (rejectIfAnotherAuthBrowserSessionPending(call)) {
            return;
        }

        openAuthSessionSavedCall = call;
        openAuthSessionCallbackScheme = callbackURLScheme;
        openAuthSessionExpectedCallbackPrefix = resolveOpenAuthSessionExpectedCallbackPrefix(url, callbackURLScheme);
        openAuthSessionPaused = false;
        openAuthSessionLaunchTimeMs = System.currentTimeMillis();

        try {
            launchCustomTab(url);
            scheduleOpenAuthSessionTimeout();
        } catch (Exception e) {
            clearOpenAuthSessionState();
            call.reject("Unable to open browser", e);
        }
    }

    @Override
    protected void handleOnPause() {
        super.handleOnPause();
        if (openAuthSessionSavedCall != null) {
            openAuthSessionPaused = true;
        }
    }

    private void launchCustomTab(String url) {
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();

        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        customTabsIntent.intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        customTabsIntent.intent.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", true);
        customTabsIntent.intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", false);
        customTabsIntent.intent.putExtra("android.support.customtabs.extra.SEND_TO_EXTERNAL_HANDLER", false);
        customTabsIntent.intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 2);
        customTabsIntent.intent.putExtra("androidx.browser.customtabs.extra.DISABLE_BACKGROUND_INTERACTION", false);
        customTabsIntent.intent.putExtra("org.chromium.chrome.browser.customtabs.EXTRA_DISABLE_DOWNLOAD_BUTTON", true);
        customTabsIntent.intent.putExtra("org.chromium.chrome.browser.customtabs.EXTRA_DISABLE_STAR_BUTTON", true);

        customTabsIntent.launchUrl(getActivity(), Uri.parse(url));
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();

        SocialProvider oauth2Provider = socialProviderHashMap.get("oauth2");
        if (oauth2Provider instanceof OAuth2Provider) {
            ((OAuth2Provider) oauth2Provider).handleUserReturnedWithoutCallback();
        }

        SocialProvider appleProvider = socialProviderHashMap.get("apple");
        if (appleProvider instanceof AppleProvider) {
            ((AppleProvider) appleProvider).handleUserReturnedWithoutCallback();
        }

        // User returned without redirect: cancel when we saw pause, or after launch grace if pause was missed
        if (openAuthSessionSavedCall != null) {
            boolean pausedAfterLaunch = openAuthSessionPaused;
            boolean missedPauseGraceElapsed =
                !openAuthSessionPaused &&
                openAuthSessionLaunchTimeMs > 0L &&
                System.currentTimeMillis() - openAuthSessionLaunchTimeMs > 750L;
            if (pausedAfterLaunch || missedPauseGraceElapsed) {
                openAuthSessionSavedCall.reject("User cancelled", USER_CANCELLED_CODE);
                clearOpenAuthSessionState();
            }
        }

        if (openSecureWindowSavedCall != null) {
            openSecureWindowSavedCall.reject("OAuth cancelled or no callback received");
            openSecureWindowSavedCall = null;
            openSecureWindowRedirectUri = null;
        }
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);

        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) {
            return;
        }

        Uri uri = intent.getData();
        if (uri == null) {
            return;
        }

        SocialProvider oauth2Provider = socialProviderHashMap.get("oauth2");
        if (oauth2Provider instanceof OAuth2Provider) {
            if (((OAuth2Provider) oauth2Provider).handleRedirectUri(uri)) {
                return;
            }
        } else {
            // Buffer until SocialLogin.initialize() registers the oauth2 provider
            pendingOAuth2RedirectUri = uri;
        }

        if (openSecureWindowRedirectUri == null && openAuthSessionCallbackScheme == null) {
            return;
        }

        if (
            openAuthSessionExpectedCallbackPrefix != null &&
            matchesOpenAuthSessionCallback(uri.toString(), openAuthSessionExpectedCallbackPrefix, openAuthSessionCallbackScheme)
        ) {
            try {
                if (openAuthSessionSavedCall != null) {
                    final JSObject ret = new JSObject();
                    ret.put("callbackURL", uri.toString());
                    openAuthSessionSavedCall.resolve(ret);
                    clearOpenAuthSessionState();
                }
            } catch (Exception e) {
                if (openAuthSessionSavedCall != null) {
                    openAuthSessionSavedCall.reject("Failed to process OAuth callback", e);
                    clearOpenAuthSessionState();
                }
            }
            return;
        }

        if (openSecureWindowRedirectUri == null) {
            return;
        }

        if (uri.getHost() == null || !uri.toString().startsWith(openSecureWindowRedirectUri)) {
            return;
        }

        try {
            // Resolve the original call with the callback url
            if (openSecureWindowSavedCall != null) {
                final JSObject ret = new JSObject();
                ret.put("redirectedUri", uri.toString());
                openSecureWindowSavedCall.resolve(ret);
                openSecureWindowSavedCall = null;
            }
        } catch (Exception e) {
            if (openSecureWindowSavedCall != null) {
                openSecureWindowSavedCall.reject("Failed to process OAuth callback", e);
                openSecureWindowSavedCall = null;
            }
        }
    }
}
