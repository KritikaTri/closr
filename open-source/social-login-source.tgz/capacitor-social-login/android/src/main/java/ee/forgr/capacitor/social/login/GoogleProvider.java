package ee.forgr.capacitor.social.login;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.common.util.concurrent.ListenableFuture;
import ee.forgr.capacitor.social.login.helpers.PluginHttpClient;
import ee.forgr.capacitor.social.login.helpers.SocialProvider;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class GoogleProvider implements SocialProvider {

    private static final String LOG_TAG = "GoogleProvider";
    private static final String USER_CANCELLED_CODE = "USER_CANCELLED";
    private static final String REAUTH_RETRY_FLAG = "_googleReauthRetry";
    private static final String SHARED_PREFERENCE_NAME = "GOOGLE_LOGIN_F13oz0I_SHARED_PERF";
    private static final String GOOGLE_DATA_PREFERENCE = "GOOGLE_LOGIN_GOOGLE_DATA_9158025e-947d-4211-ba51-40451630cc47";
    private static final Integer FUTURE_LIST_LENGTH = 128;
    private static final String TOKEN_REQUEST_URL = "https://www.googleapis.com/oauth2/v3/tokeninfo";
    private static final String OFFLINE_REFRESH_NOT_SUPPORTED_MESSAGE =
        "Google refresh() is not available when using offline mode. Offline mode only returns serverAuthCode for backend token exchange. Send serverAuthCode to your backend and refresh tokens there, or switch google.mode to 'online' for client-side refresh.";
    private static final String[] DEFAULT_SCOPES = new String[] {
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/userinfo.profile",
        "openid"
    };

    public static final Integer REQUEST_AUTHORIZE_GOOGLE_MIN = 583892990;
    public static final Integer REQUEST_AUTHORIZE_GOOGLE_MAX = REQUEST_AUTHORIZE_GOOGLE_MIN + GoogleProvider.FUTURE_LIST_LENGTH;

    private final Activity activity;
    private final Context context;
    private CredentialManager credentialManager;
    private String clientId;
    private String[] scopes;
    private final List<CallbackToFutureAdapter.Completer<AuthorizationResult>> futuresList = new ArrayList<>(FUTURE_LIST_LENGTH);

    private String idToken = null;
    private String accessToken = null;
    private GoogleProviderLoginType mode = GoogleProviderLoginType.ONLINE;
    private String hostedDomain = null;

    private static String maskClientId(String clientId) {
        if (clientId == null || clientId.isEmpty()) {
            return "(not set)";
        }
        if (clientId.length() <= 16) {
            return clientId;
        }
        return "..." + clientId.substring(clientId.length() - 20);
    }

    private static String getSigningCertificateSha1(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            String packageName = context.getPackageName();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES);
                if (info.signingInfo != null) {
                    Signature[] signatures = info.signingInfo.getApkContentsSigners();
                    if (signatures != null && signatures.length > 0) {
                        return sha1Fingerprint(signatures[0]);
                    }
                }
            } else {
                @SuppressWarnings("deprecation")
                PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation")
                Signature[] signatures = info.signatures;
                if (signatures != null && signatures.length > 0) {
                    return sha1Fingerprint(signatures[0]);
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(LOG_TAG, "Could not read app signing certificate", e);
        }
        return null;
    }

    private static String sha1Fingerprint(Signature signature) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] digest = md.digest(signature.toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                if (i > 0) {
                    sb.append(':');
                }
                sb.append(String.format("%02X", digest[i]));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    private void logGoogleCloudDiagnostics(String phase) {
        String sha1 = getSigningCertificateSha1(context);
        Log.i(
            LOG_TAG,
            String.format(
                "Google %s: package=%s signingSha1=%s webClientId=%s mode=%s",
                phase,
                context.getPackageName(),
                sha1 != null ? sha1 : "unknown",
                maskClientId(clientId),
                mode != null ? mode.name() : "unknown"
            )
        );
    }

    public enum GoogleProviderLoginType {
        ONLINE,
        OFFLINE
    }

    public GoogleProvider(Activity activity, Context context) {
        this.activity = activity;
        this.context = context;

        for (int i = 0; i < FUTURE_LIST_LENGTH; i++) {
            futuresList.add(null);
        }
    }

    public void initialize(String clientId, GoogleProviderLoginType mode, String hostedDomain) {
        this.credentialManager = CredentialManager.create(activity);
        this.clientId = clientId;
        this.mode = mode;
        this.hostedDomain = hostedDomain;
        logGoogleCloudDiagnostics("initialize");

        String data = context.getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE).getString(GOOGLE_DATA_PREFERENCE, null);

        if (data == null || data.isEmpty()) {
            Log.i(SocialLoginPlugin.LOG_TAG, "No data to restore for google login");
            return;
        }
        try {
            JSONObject object = new JSONObject(data);
            GoogleProvider.this.idToken = object.optString("idToken", null);
            String restoredAccessToken = object.optString("accessToken", null);
            GoogleProvider.this.accessToken = restoredAccessToken != null && !restoredAccessToken.isEmpty() ? restoredAccessToken : null;
            JSONArray storedScopes = object.optJSONArray("scopes");
            if (storedScopes != null && storedScopes.length() > 0) {
                List<String> scopesList = new ArrayList<>(storedScopes.length());
                for (int i = 0; i < storedScopes.length(); i++) {
                    String scope = storedScopes.optString(i, null);
                    if (scope != null && !scope.isEmpty()) {
                        scopesList.add(scope);
                    }
                }
                if (!scopesList.isEmpty()) {
                    GoogleProvider.this.scopes = scopesList.toArray(new String[0]);
                }
            }

            Log.i(
                SocialLoginPlugin.LOG_TAG,
                String.format(
                    "Google restoreState: restored idToken=%s accessToken=%s scopes=%d",
                    GoogleProvider.this.idToken != null && !GoogleProvider.this.idToken.isEmpty(),
                    GoogleProvider.this.accessToken != null && !GoogleProvider.this.accessToken.isEmpty(),
                    GoogleProvider.this.scopes != null ? GoogleProvider.this.scopes.length : 0
                )
            );
        } catch (JSONException e) {
            Log.e(SocialLoginPlugin.LOG_TAG, "Google restoreState: Failed to parse JSON", e);
        }
    }

    /**
     * Authentication-only (OIDC) scopes that Credential Manager already covers via the ID token.
     * AuthorizationClient is only needed when requesting additional Google API scopes.
     */
    private static boolean isAuthenticationOnlyScopes(String[] scopes) {
        if (scopes == null || scopes.length == 0) {
            return true;
        }
        for (String scope : scopes) {
            if (scope == null || scope.isEmpty()) {
                continue;
            }
            boolean isDefault =
                scope.equals("openid") ||
                scope.equals("https://www.googleapis.com/auth/userinfo.email") ||
                scope.equals("https://www.googleapis.com/auth/userinfo.profile") ||
                scope.equals("email") ||
                scope.equals("profile");
            if (!isDefault) {
                return false;
            }
        }
        return true;
    }

    private void resolveOnlineLogin(
        PluginCall call,
        JSObject response,
        JSObject resultObj,
        JSObject profile,
        String idToken,
        String accessToken
    ) {
        try {
            if (accessToken != null && !accessToken.isEmpty()) {
                JSObject accessTokenObj = new JSObject();
                accessTokenObj.put("token", accessToken);
                resultObj.put("accessToken", accessTokenObj);
            } else {
                // GoogleLoginResponseOnline.accessToken is nullable: ID-token auth can succeed without an access token.
                resultObj.put("accessToken", JSONObject.NULL);
                Log.i(LOG_TAG, "AuthorizationClient returned no access token; resolving online login with idToken and profile only");
            }
            resultObj.put("profile", profile);
            resultObj.put("idToken", idToken);
            resultObj.put("responseType", "online");
            response.put("result", resultObj);
            persistState(idToken, accessToken);
            call.resolve(response);
        } catch (Exception e) {
            call.reject("Error resolving Google login: " + e.getMessage());
        }
    }

    public ListenableFuture<Boolean> accessTokenIsValid(String accessToken) {
        return CallbackToFutureAdapter.getFuture((completer) -> {
            String url = TOKEN_REQUEST_URL + "?access_token=" + URLEncoder.encode(accessToken, StandardCharsets.UTF_8.name());
            PluginHttpClient.DEFAULT.enqueueGet(
                url,
                null,
                new PluginHttpClient.Callback() {
                    @Override
                    public void onFailure(IOException e) {
                        completer.setException(e);
                    }

                    @Override
                    public void onResponse(int code, String responseString) throws IOException {
                        if (!PluginHttpClient.isSuccessfulHttpCode(code)) {
                            completer.set(false);
                            Log.i(
                                LOG_TAG,
                                String.format(
                                    "Invalid response from %s. Response not successful. Status code: %s. Assuming that the token is not valid",
                                    TOKEN_REQUEST_URL,
                                    code
                                )
                            );
                            return;
                        }

                        if (responseString == null || responseString.isEmpty()) {
                            completer.setException(
                                new RuntimeException(String.format("Invalid response from %s. Response body is null", TOKEN_REQUEST_URL))
                            );
                            Log.e(LOG_TAG, String.format("Invalid response from %s. Response body is null", TOKEN_REQUEST_URL));
                            return;
                        }

                        JSONObject jsonObject;
                        try {
                            jsonObject = (JSONObject) new JSONTokener(responseString).nextValue();
                        } catch (JSONException e) {
                            completer.setException(
                                new RuntimeException(
                                    String.format(
                                        "Invalid response from %s. Response body is not a valid JSON. Error: %s",
                                        TOKEN_REQUEST_URL,
                                        e
                                    )
                                )
                            );
                            Log.e(
                                LOG_TAG,
                                String.format(
                                    "Invalid response from %s. Response body is not a valid JSON. Error: %s",
                                    TOKEN_REQUEST_URL,
                                    e
                                )
                            );
                            return;
                        }

                        String expiresIn;
                        try {
                            expiresIn = jsonObject.getString("expires_in");
                        } catch (JSONException e) {
                            completer.setException(
                                new RuntimeException(
                                    String.format(
                                        "Invalid response from %s. Response JSON does not include expires_in. Error: %s",
                                        TOKEN_REQUEST_URL,
                                        e
                                    )
                                )
                            );
                            Log.e(
                                LOG_TAG,
                                String.format(
                                    "Invalid response from %s. Response JSON does not include expires_in. Error: %s",
                                    TOKEN_REQUEST_URL,
                                    e
                                )
                            );
                            return;
                        }

                        int expressInInt;
                        try {
                            expressInInt = Integer.parseInt(expiresIn);
                        } catch (Exception e) {
                            completer.setException(
                                new RuntimeException(
                                    String.format(
                                        "Invalid response from %s. expires_in: %s is not a valid int. Error: %s",
                                        TOKEN_REQUEST_URL,
                                        expiresIn,
                                        e
                                    )
                                )
                            );
                            Log.e(
                                LOG_TAG,
                                String.format(
                                    "Invalid response from %s. expires_in: %s is not a valid int. Error: %s",
                                    TOKEN_REQUEST_URL,
                                    expiresIn,
                                    e
                                )
                            );
                            return;
                        }

                        completer.set(expressInInt > 5);
                    }
                }
            );

            return "AccessTokenIsValidOperationTag";
        });
    }

    private boolean idTokenValid(String idToken) {
        try {
            String[] parts = idToken.split("\\.");
            if (parts.length != 3) {
                return false;
            }

            // Decode payload (second part)
            String payload = new String(android.util.Base64.decode(parts[1], android.util.Base64.DEFAULT));
            JSONObject parsed = new JSONObject(payload);

            // Get current time in seconds
            long currentTime = System.currentTimeMillis() / 1000 + 5;

            // Check if token is expired
            if (parsed.has("exp")) {
                long expTime = parsed.getLong("exp");
                return currentTime < expTime;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public String arrayFind(String[] array, String search) {
        for (String s : array) {
            if (s.equals(search)) {
                return s;
            }
        }
        return null;
    }

    @Override
    public void login(PluginCall call, JSONObject config) {
        if (this.clientId == null || this.clientId.isEmpty()) {
            call.reject("Google Sign-In failed: Client ID is not set");
            return;
        }

        if (this.mode == GoogleProviderLoginType.OFFLINE && !(this.activity instanceof ModifiedMainActivityForSocialLoginPlugin)) {
            call.reject("You CANNOT use offline mode without modifying the main activity. Please follow the docs!");
            return;
        }

        logGoogleCloudDiagnostics("login");

        String nonce = config.optString("nonce");
        JSONObject options = call.getObject("options", new JSObject());
        boolean bottomUi = false;
        boolean forcePrompt = false;
        boolean filterByAuthorizedAccounts = false;
        boolean autoSelectEnabled = false;

        try {
            if (options != null) {
                bottomUi = options.has("style") && Objects.equals(options.getString("style"), "bottom");
                filterByAuthorizedAccounts = options.has("filterByAuthorizedAccounts") && options.getBoolean("filterByAuthorizedAccounts");
                autoSelectEnabled = options.has("autoSelectEnabled") && options.getBoolean("autoSelectEnabled");
                forcePrompt = options.has("forcePrompt") && options.getBoolean("forcePrompt");
            }
        } catch (JSONException e) {
            Log.e(LOG_TAG, "Error parsing options", e);
            call.reject("Error parsing options: " + e.getMessage());
            return;
        }

        // Handle scopes
        JSONArray scopesArray = config.optJSONArray("scopes");
        Set<String> uniqueScopes = new HashSet<>();

        // Add default scopes
        uniqueScopes.add("https://www.googleapis.com/auth/userinfo.email");
        uniqueScopes.add("https://www.googleapis.com/auth/userinfo.profile");
        uniqueScopes.add("openid");

        // Add custom scopes if provided
        if (scopesArray != null) {
            if (!(this.activity instanceof ModifiedMainActivityForSocialLoginPlugin)) {
                call.reject("You CANNOT use scopes without modifying the main activity. Please follow the docs!");
                return;
            }
            for (int i = 0; i < scopesArray.length(); i++) {
                uniqueScopes.add(scopesArray.optString(i));
            }
        }

        this.scopes = uniqueScopes.toArray(new String[0]);

        // Build credential request
        GetCredentialRequest.Builder requestBuilder = new GetCredentialRequest.Builder();

        Log.i(
            LOG_TAG,
            String.format(
                "Google login request: ui=%s filterByAuthorizedAccounts=%s autoSelectEnabled=%s forcePrompt=%s nonceSet=%s",
                bottomUi ? "bottom" : "standard",
                filterByAuthorizedAccounts,
                autoSelectEnabled,
                forcePrompt,
                !nonce.isEmpty()
            )
        );

        if (bottomUi) {
            GetGoogleIdOption.Builder googleIdOptionBuilder = new GetGoogleIdOption.Builder().setServerClientId(this.clientId);
            // Handle bottom UI specific options
            if (forcePrompt) {
                filterByAuthorizedAccounts = false;
                autoSelectEnabled = false;
            }

            if (!nonce.isEmpty()) {
                googleIdOptionBuilder.setNonce(nonce);
            }
            if (filterByAuthorizedAccounts) {
                googleIdOptionBuilder.setFilterByAuthorizedAccounts(true);
            }

            if (autoSelectEnabled) {
                googleIdOptionBuilder.setAutoSelectEnabled(true);
            }

            GetGoogleIdOption googleIdOptionFiltered = googleIdOptionBuilder.build();
            requestBuilder.addCredentialOption(googleIdOptionFiltered);
        } else {
            // For standard UI, we don't use these options
            GetSignInWithGoogleOption.Builder googleIdOptionBuilder = new GetSignInWithGoogleOption.Builder(this.clientId);

            if (!nonce.isEmpty()) {
                googleIdOptionBuilder.setNonce(nonce);
            }
            if (this.hostedDomain != null && !this.hostedDomain.isEmpty()) {
                googleIdOptionBuilder.setHostedDomainFilter(this.hostedDomain);
            }

            requestBuilder.addCredentialOption(googleIdOptionBuilder.build());
        }

        GetCredentialRequest filteredRequest = requestBuilder.build();

        // Execute credential request
        Executor executor = Executors.newSingleThreadExecutor();
        credentialManager.getCredentialAsync(
            context,
            filteredRequest,
            null,
            executor,
            new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override
                public void onResult(GetCredentialResponse result) {
                    handleSignInResult(result, call);
                }

                @Override
                public void onError(@NonNull GetCredentialException e) {
                    handleSignInError(e, call, config);
                }
            }
        );
    }

    private void persistState(String idToken, String accessToken) throws JSONException {
        persistState(idToken, accessToken, GoogleProvider.this.scopes);
    }

    private void persistState(String idToken, String accessToken, String[] scopes) throws JSONException {
        JSONObject object = new JSONObject();
        object.put("idToken", idToken);
        object.put("accessToken", accessToken != null ? accessToken : JSONObject.NULL);
        if (scopes != null && scopes.length > 0) {
            JSONArray scopesArray = new JSONArray();
            for (String scope : scopes) {
                if (scope != null && !scope.isEmpty()) {
                    scopesArray.put(scope);
                }
            }
            object.put("scopes", scopesArray);
        }

        GoogleProvider.this.idToken = idToken;
        GoogleProvider.this.accessToken = accessToken;

        activity
            .getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(GOOGLE_DATA_PREFERENCE, object.toString())
            .apply();
    }

    private ListenableFuture<AuthorizationResult> getAuthorizationResult(Boolean forceRefreshToken) {
        //      Account account = new Account(credential.getId(), "com.google");
        //      String scopesString = "oauth2:" + TextUtils.join(" ", this.scopes);
        //      String token = GoogleAuthUtil.getToken(
        //        this.context,
        //        account,
        //        scopesString
        //      );
        //
        //      AccessToken accessToken = new AccessToken();
        //      accessToken.token = token;
        //      accessToken.userId = credential.getId();
        //      // Note: We don't have exact expiration time, so we're not setting it here
        //
        //      return accessToken;

        ListenableFuture<AuthorizationResult> future = CallbackToFutureAdapter.getFuture((completer) -> {
            // Scopes can be null when restoring state after an app restart; default to the base OIDC/userinfo scopes.
            if (GoogleProvider.this.scopes == null || GoogleProvider.this.scopes.length == 0) {
                GoogleProvider.this.scopes = DEFAULT_SCOPES;
            }
            List<Scope> scopes = new ArrayList<>(this.scopes.length);
            for (String scope : this.scopes) {
                scopes.add(new Scope(scope));
            }
            AuthorizationRequest.Builder authorizationRequestBuilder = AuthorizationRequest.builder().setRequestedScopes(scopes);
            // .requestOfflineAccess(this.clientId)

            if (GoogleProvider.this.mode == GoogleProviderLoginType.OFFLINE) {
                authorizationRequestBuilder = authorizationRequestBuilder.requestOfflineAccess(this.clientId, forceRefreshToken);
            }

            AuthorizationRequest authorizationRequest = authorizationRequestBuilder.build();

            Identity.getAuthorizationClient(context)
                .authorize(authorizationRequest)
                .addOnSuccessListener((authorizationResult) -> {
                    if (authorizationResult.hasResolution()) {
                        // Access needs to be granted by the user
                        PendingIntent pendingIntent = authorizationResult.getPendingIntent();
                        if (pendingIntent == null) {
                            completer.setException(new RuntimeException("pendingIntent is null"));
                            Log.e(LOG_TAG, "pendingIntent is null");
                            return;
                        }

                        // Find an index to put the future into.
                        int fututeIndex = -1;
                        for (int i = 0; i < futuresList.size(); i++) {
                            if (futuresList.get(i) == null) {
                                fututeIndex = i;
                                break;
                            }
                        }

                        if (fututeIndex == -1) {
                            completer.setException(new RuntimeException("Cannot find index for future"));
                            Log.e(LOG_TAG, "Cannot find index for future. Too many login requests??");
                            return;
                        }

                        futuresList.set(fututeIndex, completer);

                        try {
                            activity.startIntentSenderForResult(
                                pendingIntent.getIntentSender(),
                                GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MIN + fututeIndex,
                                null,
                                0,
                                0,
                                0,
                                null
                            );
                        } catch (IntentSender.SendIntentException e) {
                            Log.e(LOG_TAG, "Couldn't start Authorization UI: " + e.getLocalizedMessage());
                            completer.setException(e);
                        }
                    } else {
                        // Access already granted, continue with user action.
                        // Online mode: a null access token is allowed (ID-token auth still succeeds).
                        // Offline mode still requires serverAuthCode.
                        if (this.mode == GoogleProviderLoginType.OFFLINE) {
                            if (authorizationResult.getServerAuthCode() == null) {
                                completer.setException(new RuntimeException("getServerAuthCode() is null"));
                                return;
                            }
                        } else if (this.mode == GoogleProviderLoginType.ONLINE && authorizationResult.getAccessToken() == null) {
                            Log.i(LOG_TAG, "AuthorizationResult.getAccessToken() is null; continuing with ID token authentication");
                        }

                        completer.set(authorizationResult);
                    }
                })
                .addOnFailureListener((e) -> {
                    completer.setException(new RuntimeException("Failed to authorize"));
                    Log.e(LOG_TAG, "Failed to authorize", e);
                });

            return "GetAccessTokenOperationTag";
        });

        return future;
    }

    private void handleSignInResult(GetCredentialResponse result, PluginCall call) {
        try {
            Credential credential = result.getCredential();
            if (credential instanceof CustomCredential) {
                if (GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                    JSObject user = handleSignInResult(result);
                    JSObject response = new JSObject();
                    response.put("provider", "google");
                    JSObject resultObj = new JSObject();

                    JSONObject options = call.getObject("options", new JSObject());
                    Boolean forceRefreshToken = false;
                    try {
                        forceRefreshToken = options != null && options.has("forceRefreshToken") && options.getBoolean("forceRefreshToken");
                    } catch (JSONException e) {
                        Log.e(LOG_TAG, "Error parsing forceRefreshToken option", e);
                    }

                    GoogleIdTokenCredential googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.getData());
                    String idToken = googleIdTokenCredential.getIdToken();

                    ListenableFuture<AuthorizationResult> future = getAuthorizationResult(forceRefreshToken);

                    // Use ExecutorService to retrieve the access token
                    ExecutorService executor = Executors.newSingleThreadExecutor();

                    executor.execute(
                        new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    AuthorizationResult authResult = future.get();
                                    if (GoogleProvider.this.mode == GoogleProviderLoginType.ONLINE) {
                                        // accessToken may be null: Credential Manager auth still succeeded.
                                        resolveOnlineLogin(call, response, resultObj, user, idToken, authResult.getAccessToken());
                                    } else {
                                        if (authResult.getServerAuthCode() != null) {
                                            resultObj.put("responseType", "offline");
                                            resultObj.put("serverAuthCode", authResult.getServerAuthCode());
                                            response.put("result", resultObj);
                                            call.resolve(response);
                                        } else {
                                            call.reject("Failed to get serverAuthCode");
                                        }
                                    }
                                } catch (Exception e) {
                                    // AuthorizationClient failed after Credential Manager returned a valid ID token.
                                    // For authentication-only online scopes, resolve with idToken + profile.
                                    if (
                                        GoogleProvider.this.mode == GoogleProviderLoginType.ONLINE &&
                                        idToken != null &&
                                        isAuthenticationOnlyScopes(GoogleProvider.this.scopes)
                                    ) {
                                        Log.w(
                                            LOG_TAG,
                                            "AuthorizationClient failed after successful Credential Manager auth; resolving with idToken only",
                                            e
                                        );
                                        resolveOnlineLogin(call, response, resultObj, user, idToken, null);
                                    } else {
                                        call.reject("Error retrieving access token: " + e.getMessage());
                                    }
                                } finally {
                                    executor.shutdown();
                                }
                            }
                        }
                    );

                    return; // The call will be resolved in the Runnable
                }
            }

            // If we reach here, something went wrong
            call.reject("Failed to get Google credentials");
        } catch (Exception e) {
            call.reject("Error handling sign-in result: " + e.getMessage());
        }
    }

    public void handleAuthorizationIntent(int requestCode, Intent data) {
        int futureIndex = requestCode - GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MIN;
        if (futureIndex < 0 || futureIndex >= futuresList.size()) {
            Log.e(
                LOG_TAG,
                String.format(
                    "Invalid future index. REQUEST_AUTHORIZE_GOOGLE_MIN: %d, requestCode: %d, futures list length: %d, futureIndex: %d",
                    REQUEST_AUTHORIZE_GOOGLE_MIN,
                    requestCode,
                    futuresList.size(),
                    futureIndex
                )
            );
            return;
        }

        CallbackToFutureAdapter.Completer<AuthorizationResult> future = futuresList.get(futureIndex);

        try {
            AuthorizationResult authorizationResult = Identity.getAuthorizationClient(this.activity).getAuthorizationResultFromIntent(data);
            future.set(authorizationResult);
        } catch (ApiException e) {
            Log.e(LOG_TAG, "Cannot get getAuthorizationResultFromIntent", e);
            future.setException(new RuntimeException("Cannot get getAuthorizationResultFromIntent"));
        }
    }

    private boolean isDeveloperConsoleMisconfiguration(String message) {
        return message.contains("Developer console") || message.contains("28444") || message.contains("10:");
    }

    private boolean isAccountReauthFailed(String message) {
        return message != null && message.contains("Account reauth failed");
    }

    private boolean isReauthRetry(PluginCall call) {
        return call.getData().optBoolean(REAUTH_RETRY_FLAG, false);
    }

    private void markReauthRetry(PluginCall call) {
        call.getData().put(REAUTH_RETRY_FLAG, true);
    }

    private void logAccountReauthFailedHelp(String errorMessage) {
        String sha1 = getSigningCertificateSha1(context);
        Log.e(
            LOG_TAG,
            String.format(
                "Google account reauth failed (%s). package=%s signingSha1=%s webClientId=%s. " +
                    "If only some users fail consistently: (1) OAuth consent screen must be External (not Internal/Workspace-only); " +
                    "(2) in Testing mode, each failing account must be a test user; " +
                    "(3) user may have disabled Sign in with Google for this app in Google Account settings; " +
                    "(4) Family Link / supervised accounts need filterByAuthorizedAccounts: false; " +
                    "(5) stale Credential Manager state — plugin already retried after clearing credentials; " +
                    "(6) verify Play App Signing SHA-1 for Play Store builds.",
                errorMessage,
                context.getPackageName(),
                sha1 != null ? sha1 : "unknown",
                maskClientId(clientId)
            )
        );
    }

    private void retryLoginAfterReauthFailure(PluginCall call, JSONObject config, JSONObject options) {
        try {
            options.put("style", "standard");
            options.put("filterByAuthorizedAccounts", false);
            call.getData().put("options", options);
        } catch (JSONException ex) {
            call.reject("Google Sign-In failed: " + ex.getMessage());
            return;
        }
        login(call, config);
    }

    private void handleAccountReauthFailed(GetCredentialException e, PluginCall call, JSONObject config, JSONObject options) {
        String errorMessage = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();

        if (isReauthRetry(call)) {
            logAccountReauthFailedHelp(errorMessage);
            call.reject(
                "Google Sign-In failed: [16] Account reauth failed. The plugin cleared Credential Manager credential-selection state and retried once. " +
                    "If this affects only some users, check OAuth consent screen (External vs Internal, test users in Testing mode), " +
                    "Family Link accounts (ensure filterByAuthorizedAccounts is not set to true), and whether the user disabled Sign in with Google for your app. " +
                    "See Logcat tag GoogleProvider for package, signingSha1, and webClientId."
            );
            return;
        }

        Log.w(
            LOG_TAG,
            "Account reauth failed; clearing Credential Manager credential-selection state and retrying with standard sign-in flow."
        );
        markReauthRetry(call);

        clearCredentialManagerState(
            new CredentialManagerCallback<Void, Exception>() {
                @Override
                public void onResult(Void unused) {
                    retryLoginAfterReauthFailure(call, config, options);
                }

                @Override
                public void onError(@NonNull Exception clearError) {
                    Log.w(LOG_TAG, "Failed to clear Credential Manager state before reauth retry; retrying sign-in anyway.", clearError);
                    retryLoginAfterReauthFailure(call, config, options);
                }
            }
        );
    }

    private void logDeveloperConsoleMisconfigurationHelp(String errorMessage) {
        String sha1 = getSigningCertificateSha1(context);
        Log.e(
            LOG_TAG,
            String.format(
                "Google Credential Manager rejected this app (%s). package=%s signingSha1=%s webClientId=%s. " +
                    "Checklist: (1) webClientId must be a Web OAuth client ID, not Android; " +
                    "(2) create an Android OAuth client with this exact package + SHA-1 in the same GCP project; " +
                    "(3) add Play App Signing SHA-1 for Play Store builds; " +
                    "(4) add test users if OAuth consent screen is in Testing; " +
                    "(5) allow several hours for console changes to propagate.",
                errorMessage,
                context.getPackageName(),
                sha1 != null ? sha1 : "unknown",
                maskClientId(clientId)
            )
        );
    }

    private void handleSignInError(GetCredentialException e, PluginCall call, JSONObject config) {
        String errorMessage = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
        Log.e(LOG_TAG, "Google Sign-In failed: " + errorMessage, e);

        if (isDeveloperConsoleMisconfiguration(errorMessage)) {
            logDeveloperConsoleMisconfigurationHelp(errorMessage);
            call.reject(
                "Google Sign-In failed: Google Cloud OAuth is not configured for this installed build (" +
                    errorMessage +
                    "). Check Logcat tag GoogleProvider for package, signingSha1, and webClientId, then see the Android troubleshooting section in the plugin README."
            );
            return;
        }

        boolean isBottomUi = false;
        JSONObject options = call.getObject("options", new JSObject());
        if (options.has("style")) {
            try {
                isBottomUi = options.getString("style").equals("bottom");
            } catch (JSONException ex) {
                // do nothing
            }
        }
        if (isAccountReauthFailed(errorMessage)) {
            handleAccountReauthFailed(e, call, config, options);
            return;
        }
        if (e instanceof GetCredentialCancellationException) {
            call.reject("Google Sign-In cancelled by user", USER_CANCELLED_CODE, e);
            return;
        }
        if (e instanceof NoCredentialException) {
            // Check if filterByAuthorizedAccounts is set (default is false if not explicitly set to false)
            boolean filterByAuthorizedAccountsValue = false;
            try {
                if (options.has("filterByAuthorizedAccounts")) {
                    filterByAuthorizedAccountsValue = options.getBoolean("filterByAuthorizedAccounts");
                }
            } catch (JSONException ex) {
                // Ignore, use default
            }

            if (isBottomUi) {
                Log.e(
                    LOG_TAG,
                    "No Google accounts available with bottomUi. This may be due to Family Link supervised accounts when filterByAuthorizedAccounts is true. Switching to standard UI."
                );
                // During the get credential flow, this is returned when no viable credential is available for the the user. This can be caused by various scenarios such as that the user doesn't have any credential or the user doesn't grant consent to using any available credential. Upon this exception, your app should navigate to use the regular app sign-up or sign-in screen.
                // https://developer.android.com/reference/androidx/credentials/exceptions/NoCredentialException
                // Note: Family Link supervised accounts may cause this error when filterByAuthorizedAccounts is true
                try {
                    options.put("style", "standard");
                    call.getData().put("options", options);
                } catch (JSONException ex) {
                    call.reject("Google Sign-In failed: " + ex.getMessage());
                    return;
                }
                login(call, config);
            } else {
                // If it's already standard UI, provide more detailed error message
                if (filterByAuthorizedAccountsValue) {
                    call.reject(
                        "Google Sign-In failed: No credentials available. If signing in with a Family Link supervised account, try setting filterByAuthorizedAccounts to false."
                    );
                } else {
                    call.reject("Google Sign-In failed: " + e.getMessage());
                }
            }
        } else {
            call.reject("Google Sign-In failed: " + e.getMessage());
        }
    }

    private JSObject handleSignInResult(GetCredentialResponse result) throws JSONException {
        JSObject user = new JSObject();
        Log.d(LOG_TAG, "handleSignInResult: " + result.toString());

        Credential credential = result.getCredential();
        if (credential instanceof CustomCredential) {
            if (GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                GoogleIdTokenCredential googleIdTokenCredential = GoogleIdTokenCredential.createFrom(
                    ((CustomCredential) credential).getData()
                );
                user.put("id", googleIdTokenCredential.getId());
                user.put("name", googleIdTokenCredential.getDisplayName());
                user.put("email", googleIdTokenCredential.getId());
                user.put("familyName", googleIdTokenCredential.getFamilyName());
                user.put("givenName", googleIdTokenCredential.getGivenName());
                user.put("imageUrl", googleIdTokenCredential.getProfilePictureUri());

                try {
                    String[] parts = googleIdTokenCredential.getIdToken().split("\\.");
                    if (parts.length != 3) {
                        throw new RuntimeException("JWT parts length != 3 (how is this possible??)");
                    }

                    // Decode payload (second part)
                    String payload = new String(android.util.Base64.decode(parts[1], android.util.Base64.DEFAULT));
                    JSONObject parsed = new JSONObject(payload);

                    // Get current time in seconds
                    long currentTime = System.currentTimeMillis() / 1000 + 5;

                    // Check if token is expired
                    if (parsed.has("sub")) {
                        String sub = parsed.getString("sub");
                        user.put("id", sub);
                    } else {
                        throw new RuntimeException("No SUB field in the JWT");
                    }
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Cannot get id from id_token", e);
                }
            }
        }
        return user;
    }

    private void clearCredentialManagerState(CredentialManagerCallback<Void, Exception> handler) {
        ClearCredentialStateRequest request = new ClearCredentialStateRequest();

        Executor executor = Executors.newSingleThreadExecutor();
        credentialManager.clearCredentialStateAsync(
            request,
            null,
            executor,
            new CredentialManagerCallback<Void, ClearCredentialException>() {
                @Override
                public void onResult(Void result) {
                    handler.onResult(null);
                }

                @Override
                public void onError(@NonNull ClearCredentialException e) {
                    handler.onError(e);
                }
            }
        );
    }

    private void completeLocalLogout(CredentialManagerCallback<Void, Exception> handler) {
        context.getSharedPreferences(SHARED_PREFERENCE_NAME, Context.MODE_PRIVATE).edit().clear().apply();
        GoogleProvider.this.accessToken = null;
        GoogleProvider.this.idToken = null;
        handler.onResult(null);
    }

    private void rawLogout(CredentialManagerCallback<Void, Exception> handler) {
        Log.i(LOG_TAG, "Logout requested");
        clearCredentialManagerState(
            new CredentialManagerCallback<Void, Exception>() {
                @Override
                public void onResult(Void unused) {
                    GoogleRestoreCredentialHelper.clearRestoreCredential(
                        context,
                        new CredentialManagerCallback<Void, Exception>() {
                            @Override
                            public void onResult(Void unusedRestore) {
                                completeLocalLogout(handler);
                            }

                            @Override
                            public void onError(@NonNull Exception e) {
                                Log.e(LOG_TAG, "Failed to clear restore credential during logout", e);
                                handler.onError(e);
                            }
                        }
                    );
                }

                @Override
                public void onError(@NonNull Exception e) {
                    Log.e(LOG_TAG, "Failed to clear credential state", e);
                    handler.onError(e);
                }
            }
        );
    }

    public void createRestoreCredential(PluginCall call) {
        JSObject options = call.getObject("options", new JSObject());
        String requestJson = options.getString("requestJson");
        boolean isCloudBackupEnabled = !options.has("isCloudBackupEnabled") || options.getBoolean("isCloudBackupEnabled", true);

        try {
            GoogleRestoreCredentialHelper.validateRequestJson(requestJson);
        } catch (IllegalArgumentException e) {
            call.reject(e.getMessage());
            return;
        }

        GoogleRestoreCredentialHelper.createRestoreCredential(
            context,
            requestJson,
            isCloudBackupEnabled,
            new CredentialManagerCallback<
                androidx.credentials.CreateRestoreCredentialResponse,
                androidx.credentials.exceptions.CreateCredentialException
            >() {
                @Override
                public void onResult(androidx.credentials.CreateRestoreCredentialResponse response) {
                    try {
                        JSObject result = new JSObject().put("responseJson", response.getResponseJson());
                        call.resolve(result);
                    } catch (Exception e) {
                        call.reject("Failed to create restore credential: " + e.getMessage());
                    }
                }

                @Override
                public void onError(@NonNull androidx.credentials.exceptions.CreateCredentialException e) {
                    String message = e.getErrorMessage() != null ? e.getErrorMessage().toString() : e.getMessage();
                    call.reject("Failed to create restore credential: " + message);
                }
            }
        );
    }

    public void getRestoreCredential(PluginCall call) {
        JSObject options = call.getObject("options", new JSObject());
        String requestJson = options.getString("requestJson");

        try {
            GoogleRestoreCredentialHelper.validateRequestJson(requestJson);
        } catch (IllegalArgumentException e) {
            call.reject(e.getMessage());
            return;
        }

        GoogleRestoreCredentialHelper.getRestoreCredential(
            context,
            requestJson,
            new CredentialManagerCallback<String, Exception>() {
                @Override
                public void onResult(String responseJson) {
                    try {
                        JSObject result = new JSObject().put("responseJson", responseJson);
                        call.resolve(result);
                    } catch (Exception e) {
                        call.reject("Failed to get restore credential: " + e.getMessage());
                    }
                }

                @Override
                public void onError(@NonNull Exception e) {
                    if (e instanceof NoCredentialException) {
                        call.reject("No restore credential available");
                        return;
                    }
                    if (e instanceof GetCredentialCancellationException) {
                        call.reject("Restore credential request cancelled", USER_CANCELLED_CODE, e);
                        return;
                    }
                    String message = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                    call.reject("Failed to get restore credential: " + message);
                }
            }
        );
    }

    public void clearRestoreCredential(PluginCall call) {
        GoogleRestoreCredentialHelper.clearRestoreCredential(
            context,
            new CredentialManagerCallback<Void, Exception>() {
                @Override
                public void onResult(Void unused) {
                    call.resolve(new JSObject().put("cleared", true));
                }

                @Override
                public void onError(@NonNull Exception e) {
                    String message = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                    call.reject("Failed to clear restore credential: " + message);
                }
            }
        );
    }

    @Override
    public void logout(PluginCall call) {
        if (this.mode == GoogleProviderLoginType.OFFLINE) {
            call.reject("logout is not implemented when using offline mode");
            return;
        }
        rawLogout(
            new CredentialManagerCallback<Void, Exception>() {
                @Override
                public void onResult(Void unused) {
                    call.resolve();
                }

                @Override
                public void onError(@NonNull Exception e) {
                    call.reject("Failed to clear credential state: " + e.getMessage());
                }
            }
        );
    }

    @Override
    public void getAuthorizationCode(PluginCall call) {
        if (this.mode == GoogleProviderLoginType.OFFLINE) {
            call.reject("getAuthorizationCode is not implemented when using offline mode");
            return;
        }
        if (GoogleProvider.this.idToken == null || GoogleProvider.this.idToken.isEmpty()) {
            call.reject("User is not logged in");
            return;
        }
        try {
            boolean isValidIdToken = idTokenValid(GoogleProvider.this.idToken);
            if (!isValidIdToken) {
                rawLogout(
                    new CredentialManagerCallback<>() {
                        @Override
                        public void onResult(Void unused) {
                            call.reject("User is not logged in");
                        }

                        @Override
                        public void onError(@NonNull Exception e) {
                            Log.e(LOG_TAG, "Saved id token isn't valid, but logout failed", e);
                            call.reject("User is not logged in");
                        }
                    }
                );
                return;
            }

            // Access token may be null for authentication-only sessions.
            if (GoogleProvider.this.accessToken != null && !GoogleProvider.this.accessToken.isEmpty()) {
                ListenableFuture<Boolean> accessTokenValidFuture = accessTokenIsValid(GoogleProvider.this.accessToken);
                boolean isValidAccessToken = accessTokenValidFuture.get(7, TimeUnit.SECONDS);
                if (!isValidAccessToken) {
                    // Keep the valid ID token session; clear only the stale access token.
                    GoogleProvider.this.accessToken = null;
                    persistState(GoogleProvider.this.idToken, null, GoogleProvider.this.scopes);
                }
            }

            JSObject result = new JSObject().put("jwt", GoogleProvider.this.idToken);
            if (GoogleProvider.this.accessToken != null && !GoogleProvider.this.accessToken.isEmpty()) {
                result.put("accessToken", GoogleProvider.this.accessToken);
            } else {
                result.put("accessToken", JSONObject.NULL);
            }
            call.resolve(result);
        } catch (Exception e) {
            Log.e(LOG_TAG, "Error validating tokens", e);
            call.reject("Error validating tokens: " + e.getMessage());
        }
    }

    @Override
    public void isLoggedIn(PluginCall call) {
        if (this.mode == GoogleProviderLoginType.OFFLINE) {
            call.reject("isLoggedIn is not implemented when using offline mode");
            return;
        }
        if (GoogleProvider.this.idToken == null || GoogleProvider.this.idToken.isEmpty()) {
            call.resolve(new JSObject().put("isLoggedIn", false));
            return;
        }
        try {
            boolean isValidIdToken = idTokenValid(GoogleProvider.this.idToken);
            if (!isValidIdToken) {
                rawLogout(
                    new CredentialManagerCallback<>() {
                        @Override
                        public void onResult(Void unused) {
                            call.resolve(new JSObject().put("isLoggedIn", false));
                        }

                        @Override
                        public void onError(@NonNull Exception e) {
                            Log.e(LOG_TAG, "Saved id token isn't valid, but logout failed", e);
                            call.resolve(new JSObject().put("isLoggedIn", false));
                        }
                    }
                );
                return;
            }

            // Valid ID token is enough for authentication-only sessions.
            if (GoogleProvider.this.accessToken != null && !GoogleProvider.this.accessToken.isEmpty()) {
                ListenableFuture<Boolean> accessTokenValidFuture = accessTokenIsValid(GoogleProvider.this.accessToken);
                boolean isValidAccessToken = accessTokenValidFuture.get(7, TimeUnit.SECONDS);
                if (!isValidAccessToken) {
                    GoogleProvider.this.accessToken = null;
                    persistState(GoogleProvider.this.idToken, null, GoogleProvider.this.scopes);
                }
            }
            call.resolve(new JSObject().put("isLoggedIn", true));
        } catch (Exception e) {
            Log.e(LOG_TAG, "Error validating tokens", e);
            call.reject("Error validating tokens: " + e.getMessage());
        }
    }

    @Override
    public void refresh(PluginCall call) {
        if (this.mode == GoogleProviderLoginType.OFFLINE) {
            Log.w(LOG_TAG, OFFLINE_REFRESH_NOT_SUPPORTED_MESSAGE);
            call.reject(OFFLINE_REFRESH_NOT_SUPPORTED_MESSAGE);
            return;
        }
        if (this.clientId == null || this.clientId.isEmpty()) {
            call.reject("Google Sign-In failed: Client ID is not set");
            return;
        }
        if (this.credentialManager == null) {
            this.credentialManager = CredentialManager.create(activity);
        }

        // If tokens needed for the current session type are still valid, do nothing.
        try {
            if (GoogleProvider.this.idToken != null) {
                boolean isValidIdToken = idTokenValid(GoogleProvider.this.idToken);
                boolean accessOk = true;
                if (GoogleProvider.this.accessToken != null && !GoogleProvider.this.accessToken.isEmpty()) {
                    accessOk = accessTokenIsValid(GoogleProvider.this.accessToken).get(7, TimeUnit.SECONDS);
                }
                if (isValidIdToken && accessOk) {
                    call.resolve();
                    return;
                }
            }
        } catch (Exception e) {
            // Non-fatal: fall through to attempt refresh.
            Log.w(LOG_TAG, "Error checking token validity during refresh", e);
        }

        // Ensure we have scopes for the authorization flow (may be null after restoreState).
        if (GoogleProvider.this.scopes == null || GoogleProvider.this.scopes.length == 0) {
            GoogleProvider.this.scopes = DEFAULT_SCOPES;
        }

        // 1) Retrieve a fresh ID token via Credential Manager (may be silent or may require user interaction).
        // 2) Retrieve a fresh access token via the Authorization API (may be null for auth-only sessions).
        GetCredentialRequest request = new GetCredentialRequest.Builder()
            .addCredentialOption(
                new GetGoogleIdOption.Builder()
                    .setServerClientId(this.clientId)
                    .setFilterByAuthorizedAccounts(true)
                    .setAutoSelectEnabled(true)
                    .build()
            )
            .build();

        ExecutorService executor = Executors.newSingleThreadExecutor();
        credentialManager.getCredentialAsync(
            context,
            request,
            null,
            executor,
            new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override
                public void onResult(GetCredentialResponse result) {
                    try {
                        Credential credential = result.getCredential();
                        if (!(credential instanceof CustomCredential)) {
                            call.reject("Failed to refresh tokens: unexpected credential type");
                            return;
                        }

                        if (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                            call.reject("Failed to refresh tokens: unexpected credential subtype");
                            return;
                        }

                        GoogleIdTokenCredential googleIdTokenCredential = GoogleIdTokenCredential.createFrom(
                            ((CustomCredential) credential).getData()
                        );
                        String newIdToken = googleIdTokenCredential.getIdToken();

                        ListenableFuture<AuthorizationResult> future = getAuthorizationResult(false);

                        ExecutorService authExecutor = Executors.newSingleThreadExecutor();
                        authExecutor.execute(
                            new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        AuthorizationResult authResult = future.get(60, TimeUnit.SECONDS);
                                        String newAccessToken = authResult.getAccessToken();
                                        // Persist ID token even when access token is unavailable.
                                        persistState(
                                            newIdToken,
                                            newAccessToken != null && !newAccessToken.isEmpty() ? newAccessToken : null,
                                            GoogleProvider.this.scopes
                                        );
                                        call.resolve();
                                    } catch (Exception e) {
                                        if (isAuthenticationOnlyScopes(GoogleProvider.this.scopes)) {
                                            try {
                                                // Authorization failed; still keep the refreshed ID token.
                                                persistState(newIdToken, null, GoogleProvider.this.scopes);
                                                call.resolve();
                                            } catch (JSONException persistError) {
                                                call.reject("Failed to refresh tokens: " + e.getMessage());
                                            }
                                        } else {
                                            call.reject("Failed to refresh tokens: " + e.getMessage());
                                        }
                                    } finally {
                                        authExecutor.shutdown();
                                    }
                                }
                            }
                        );
                    } catch (Exception e) {
                        call.reject("Failed to refresh tokens: " + e.getMessage());
                    } finally {
                        executor.shutdown();
                    }
                }

                @Override
                public void onError(@NonNull GetCredentialException e) {
                    if (e instanceof NoCredentialException) {
                        call.reject("User not logged in");
                        executor.shutdown();
                        return;
                    }
                    call.reject("Failed to refresh tokens: " + e.getMessage());
                    executor.shutdown();
                }
            }
        );
    }
}
